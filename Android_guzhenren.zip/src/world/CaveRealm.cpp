// 洞天 / 福地内部地图（秘境）实现
//
//  生成策略：
//    · 尺寸依洞天层级：福地小而精（48×36），洞天大而全（96×72）
//    · 地形风格随洞天种类：
//        天道原生秘境   → 混沌裂隙、遗迹为主
//        异人 / 异族洞天 → 聚落、灵田
//        原著有名福地   → 灵田灵泉山岳俱全（如琅琊福地、狐仙福地）
//        天庭洞天集群   → 规整聚落与灵脉
//        太古七天碎片   → 荒芜遗迹
//    · 九层结构（疯魔窟）逐层按原著描述生成：
//        一层雨林 / 二层火岩石滩 / 三层云竹雾都 / … / 九层元境书山
//
//  原著边界（重要）：
//    原著对多数洞天内部只给了少量定点，未给完整布局。
//    故本模块产出的是【结构示意】而非考据地图 ——
//    原著提到的地点定点放置并标 canon=true，其余为工程构造填充。
#include "gr/world/CaveRealm.hpp"
#include "gr/world/CaveParadise.hpp"

#include <algorithm>
#include <cmath>

namespace gr {

// ---------------------------------------------------------------------------
//  CaveFloorMap
// ---------------------------------------------------------------------------
CaveTile& CaveFloorMap::at(int x, int y) {
    return tiles[static_cast<std::size_t>(y) * w + x];
}
const CaveTile& CaveFloorMap::at(int x, int y) const {
    return tiles[static_cast<std::size_t>(y) * w + x];
}

int CaveFloorMap::reveal(int cx, int cy, int r) {
    int newly = 0;
    for (int y = cy - r; y <= cy + r; ++y) {
        for (int x = cx - r; x <= cx + r; ++x) {
            if (!inBounds(x, y)) continue;
            const int dx = x - cx, dy = y - cy;
            if (dx * dx + dy * dy > r * r) continue;
            CaveTile& t = at(x, y);
            if (!t.explored) { t.explored = true; ++newly; }
        }
    }
    return newly;
}

double CaveFloorMap::exploredRatio() const {
    if (tiles.empty()) return 0.0;
    long long n = 0;
    for (const auto& t : tiles) if (t.explored) ++n;
    return static_cast<double>(n) / tiles.size();
}

void CaveFloorMap::revealAll() {
    for (auto& t : tiles) t.explored = true;
}

// ---------------------------------------------------------------------------
//  CaveRealm
// ---------------------------------------------------------------------------
CaveRealm::CaveRealm(const std::string& siteId, const std::string& name, int levels)
    : siteId_(siteId), name_(name) {
    floors_.resize(static_cast<std::size_t>(std::max(1, levels)));
    for (int i = 0; i < static_cast<int>(floors_.size()); ++i)
        floors_[i].level = i + 1;
}

CaveFloorMap& CaveRealm::floor(int lv) {
    const int i = std::clamp(lv - 1, 0, static_cast<int>(floors_.size()) - 1);
    return floors_[static_cast<std::size_t>(i)];
}
const CaveFloorMap& CaveRealm::floor(int lv) const {
    const int i = std::clamp(lv - 1, 0, static_cast<int>(floors_.size()) - 1);
    return floors_[static_cast<std::size_t>(i)];
}

// ---------------------------------------------------------------------------
//  原著定点放置
// ---------------------------------------------------------------------------
namespace {

// 疯魔窟九层：原著明确给出各层环境
const char* fengmokuFloorName(int lv) {
    switch (lv) {
        case 1: return "第一层·外部入口（雨林式外部世界）";
        case 2: return "第二层·火岩石滩";
        case 3: return "第三层·云竹、云雾、猛兽、无声雾都";
        case 4: return "第四层";
        case 5: return "第五层";
        case 6: return "第六层·小山谷（疯魔三怪活动）";
        case 7: return "第七层·接近天道梦境";
        case 8: return "第八层·自在天痕";
        case 9: return "第九层·魔音源头（元境、书山、疯魔九虚阵）";
    }
    return "未知层";
}

} // namespace

void CaveRealmGenerator::placeCanonSites(CaveFloorMap& f, const CaveParadise& cave,
                                         int level) {
    auto put = [&](const char* id, const char* name, const char* desc,
                   double fx, double fy, const char* src, bool canon) {
        CaveSite s;
        s.id = id; s.name = name; s.desc = desc;
        s.x = static_cast<int>(f.w * fx);
        s.y = static_cast<int>(f.h * fy);
        s.source = src; s.canon = canon;
        const std::int16_t idx = static_cast<std::int16_t>(f.sites.size());
        f.sites.push_back(s);
        if (f.inBounds(s.x, s.y)) {
            f.at(s.x, s.y).landmarkId = idx;
            f.at(s.x, s.y).terrain = CaveTerrain::Landmark;
        }
    };

    // —— 疯魔窟：九层嵌套，原著逐层描述 ——
    if (cave.siteId == "cn_fengmo_ku") {
        if (level == 9) {
            put("yuanjing", "元境", "疯魔窟最底层；含一切流派奥妙，"
                "进入对应部分可成为流派无上大宗师",
                0.30, 0.40, "地理研究：疯魔窟第九层·元境", true);
            put("shushan", "书山", "元境中的书山，与衍化蛊同为核心",
                0.62, 0.38, "地理研究：疯魔窟第九层·书山", true);
            put("fengmojiuxuzhen", "疯魔九虚阵", "以元境、书山、九转衍化蛊为核心，"
                "持续刺穿世界胎壁、吸纳域外混沌、炼化天道道痕",
                0.50, 0.62, "地理研究：疯魔九虚阵", true);
        }
        return;
    }

    // —— 琅琊福地：荡魂山、落魄谷在其内 ——
    if (cave.siteId.find("langya") != std::string::npos ||
        cave.name.find("琅琊") != std::string::npos) {
        put("danghunshan", "荡魂山", "魂道奇山，后被收于琅琊福地 —— 属仙窍内坐标",
            0.32, 0.36, "地理研究：著名地点清单", true);
        put("luopogu", "落魄谷", "琅琊福地内部的特殊地形/资源，随福地迁移",
            0.62, 0.58, "地理研究：著名地点清单", true);
        return;
    }

    // —— 至尊仙窍：内部有「小东海」，逆流河置于其中 ——
    if (cave.siteId == "cn_zunzhe_xiantiao") {
        put("xiaodonghai", "小东海", "至尊仙窍内的东海式区域；"
            "说明方源把不同来源的规则地貌收纳进自家仙窍时空",
            0.72, 0.60, "地理研究：至尊仙窍内部", true);
        put("niliuhe", "逆流河", "至尊仙窍内「小东海」区域的宙道/规则型河流，方源可控",
            0.74, 0.52, "地理研究：著名地点清单", true);
        return;
    }

    // —— 地沟：原著实有，内部依原著描述定点 ——
    if (cave.siteId.find("digou") != std::string::npos) {
        if (level == 1) {
            put("goukou", "沟口", "地沟的入口，宛若恶兽张开的血盆大口；"
                "自此向下，沟壑将扩大数十倍乃至上百倍",
                0.50, 0.12, "原著 2107 节：地沟宛若恶兽的血盆大口", true);
        } else if (level == 3) {
            put("heiyouhe", "黑油河", "地沟中盛产黑油，彼此交错纠缠，"
                "宛若一群怪异的巨蟒，近乎静止却又缓缓流动",
                0.50, 0.45, "原著：地沟中的黑油相互交错纠缠，仿佛一群怪异的巨蟒", true);
        } else if (level == 4) {
            put("huangshouyuan", "荒兽渊", "越是深入，猛兽、诡异植株、"
                "野生蛊虫便比比皆是；夜叉章鱼在两侧峭壁上凿洞而居",
                0.50, 0.55, "原著：越是深入地沟，各种猛兽、诡异的植物、野生的蛊虫就比比皆是", true);
        } else if (level == 5) {
            put("diqiao_woniu", "地壳蜗牛栖处", "地壳蜗牛生于地沟极深处，"
                "距地表上万里；性情温顺，可立于其背。身后粘涎可加工为星夜黏涎",
                0.50, 0.70, "原著：地壳蜗牛生活在地沟的极深处，性情温顺，"
                            "粘涎可加工成星夜黏涎（六转仙材）", true);
            put("shenbujiandi", "深不见底", "这道地沟有多深无人知晓，"
                "就连把持多年的仙僵也从未探到沟底",
                0.30, 0.85, "原著：就算是掌控这里这么多年的仙僵们，"
                            "也从未有人探查到地沟的真正底", true);
        }
        return;
    }

    // —— 狐仙福地 ——
    if (cave.siteId == "nj_huxian_fudi") {
        put("huxiandongfu", "狐仙洞府", "狐仙福地的核心居所",
            0.50, 0.44, "地理研究：狐仙福地", true);
        return;
    }
}

// ---------------------------------------------------------------------------
//  单层生成
// ---------------------------------------------------------------------------
// 大地裂缝层名（B 级推演：地脉翻涌所致）
namespace {
bool crackFloorName(int level, std::string& out) {
    switch (level) {
        case 1: out = "第一层·沟口"; return true;
        case 2: out = "第二层·崖壁"; return true;
        case 3: out = "第三层·黑油河"; return true;
        case 4: out = "第四层·荒兽渊"; return true;
        case 5: out = "第五层·深不见底"; return true;
        default: return false;
    }
}
} // namespace

CaveRealmGenerator::Result CaveRealmGenerator::genSingleFloor(
    CaveFloorMap& f, const CaveParadise& cave, int level, int levels, Rng& rng) {

    const std::uint32_t seed = static_cast<std::uint32_t>(rng.rangeInt(1, 1000000));

    // 疯魔窟逐层命名
    if (cave.siteId == "cn_fengmo_ku") {
        f.name = fengmokuFloorName(level);
    } else if (crackFloorName(level, f.name)) {
        // 大地裂缝层名
    } else if (levels > 1) {
        f.name = "第 " + std::to_string(level) + " 层";
    } else {
        f.name = cave.name;
    }

    // 基础填充：噪声决定地貌
    auto hash2 = [&](int x, int y) {
        std::uint32_t h = seed;
        h ^= static_cast<std::uint32_t>(x) * 374761393u;
        h ^= static_cast<std::uint32_t>(y) * 668265263u;
        h = (h ^ (h >> 13)) * 1274126177u;
        return static_cast<double>((h ^ (h >> 16)) & 0xFFFF) / 65536.0;
    };
    auto noise = [&](double x, double y) {
        const int xi = static_cast<int>(std::floor(x)), yi = static_cast<int>(std::floor(y));
        const double xf = x - xi, yf = y - yi;
        const double u = xf * xf * (3 - 2 * xf), v = yf * yf * (3 - 2 * yf);
        const double a = hash2(xi, yi), b = hash2(xi + 1, yi);
        const double c = hash2(xi, yi + 1), d = hash2(xi + 1, yi + 1);
        const double p = a + (b - a) * u, q = c + (d - c) * u;
        return p + (q - p) * v;
    };

    for (int y = 0; y < f.h; ++y) {
        for (int x = 0; x < f.w; ++x) {
            CaveTile& t = f.at(x, y);
            t = CaveTile{};

            // 边界：留一圈虚空，形成洞天壁障
            const int edge = std::min({x, y, f.w - 1 - x, f.h - 1 - y});
            if (edge <= 0) { t.terrain = CaveTerrain::Void; continue; }

            const double n  = noise(x * 0.16, y * 0.16);
            const double n2 = noise(x * 0.34 + 31.7, y * 0.34 + 17.3);

            // 依洞天种类决定风格
            if (cave.siteId.find("digou") != std::string::npos) {
                // —— 地沟：上窄下阔，宛若恶兽的血盆大口 ——
                //
                //  【已更正】此前做成「越深越窄」，与原著相反。原著 2107 节：
                //    「地沟宛若恶兽的血盆大口，在浓郁的黑暗当中静默地张开。」
                //    「沟壑渐渐扩大数十倍、上百倍……内部已经广阔到
                //      可以装下七八十个阴流巨城的地步。」
                //  故是【越深越阔】：沟口狭窄，往下层层扩张。
                //
                //  两侧为悬崖峭壁（原著：「两边的悬崖峭壁上，大部分都是
                //  光秃陡峭，只有些微的针刺植株像是芝麻一般点缀在上面」）。
                const double px = static_cast<double>(x), py = static_cast<double>(y);

                // 沟心随纵向蜿蜒
                const double cx = f.w * 0.5 +
                    (noise(py * 0.11, static_cast<double>(level) * 3.7) - 0.5) * f.w * 0.40;
                // 半宽随层数扩张：越深越阔（血盆大口）
                const double base = f.w * (0.16 + 0.075 * (level - 1));
                const double half = base * (0.84 + 0.28 * noise(px * 0.26 + 51.1, py * 0.15));
                const double d = std::fabs(px - cx) / half;

                if (d > 1.30) {
                    // 沟壁之外：悬崖峭壁，光秃陡峭
                    t.terrain = CaveTerrain::CrackWall;
                } else if (d > 1.0) {
                    // 沟沿：峭壁上仅有的落脚处，散布针刺植株
                    t.terrain = (noise(px * 0.5, py * 0.5) > 0.72)
                                    ? CaveTerrain::BeastNest      // 夜叉章鱼凿洞而居
                                    : CaveTerrain::CrackEdge;
                } else {
                    // 沟内：越深越荒，黑油成河
                    const double nn  = noise(px * 0.20 + 13.1, py * 0.20 + 7.7);
                    const double nn2 = noise(px * 0.09 + 61.3, py * 0.09 + 29.1);
                    const int lv = level;
                    // 黑油河：第三层起显著（原著：地沟盛产黑油）
                    const bool oilBand = (lv >= 3) && (nn2 > 0.60) && (nn2 < 0.78);
                    if (oilBand)                  t.terrain = CaveTerrain::BlackOil;
                    else if (nn < 0.16 + 0.05 * (lv - 1))
                                                  t.terrain = CaveTerrain::DarkDepths;
                    else if (lv >= 4 && nn > 0.70) t.terrain = CaveTerrain::BeastNest;
                    else                           t.terrain = CaveTerrain::FallenDebris;
                }
                continue;
            }
            if (cave.siteId == "cn_fengmo_ku") {
                // 九层各有环境（原著逐层描述）
                switch (level) {
                    case 1:  t.terrain = n > 0.62 ? CaveTerrain::Forest
                                       : (n < 0.30 ? CaveTerrain::Water : CaveTerrain::Rainforest);
                             break;
                    case 2:  t.terrain = n > 0.55 ? CaveTerrain::LavaRock
                                       : (n2 < 0.22 ? CaveTerrain::MineVein : CaveTerrain::Mountain);
                             break;
                    case 3:  t.terrain = n2 > 0.72 ? CaveTerrain::MistCity
                                       : (n > 0.52 ? CaveTerrain::Bamboo
                                       : (n2 < 0.20 ? CaveTerrain::BeastNest : CaveTerrain::Floor));
                             break;
                    case 9:  t.terrain = (n > 0.70 || n2 > 0.78) ? CaveTerrain::YuanJing
                                       : (n < 0.28 ? CaveTerrain::BookMountain
                                       : (n2 < 0.18 ? CaveTerrain::ChaoticRift : CaveTerrain::Floor));
                             break;
                    default: t.terrain = n > 0.66 ? CaveTerrain::Mountain
                                       : (n < 0.28 ? CaveTerrain::Water
                                       : (n2 < 0.18 ? CaveTerrain::BeastNest : CaveTerrain::Floor));
                             break;
                }
            } else if (cave.kind == CaveKind::HeavenDaoSecret) {
                // 天道原生秘境：混沌裂隙与遗迹为主
                t.terrain = n2 < 0.16 ? CaveTerrain::ChaoticRift
                          : (n > 0.72 ? CaveTerrain::Ruins
                          : (n < 0.26 ? CaveTerrain::SpiritSpring : CaveTerrain::Floor));
            } else if (cave.kind == CaveKind::YirenCave ||
                       cave.kind == CaveKind::YizuCave) {
                // 异人 / 异族洞天：聚落与灵田
                t.terrain = n2 < 0.14 ? CaveTerrain::Settlement
                          : (n < 0.32 ? CaveTerrain::SpiritField
                          : (n > 0.68 ? CaveTerrain::Forest : CaveTerrain::Floor));
            } else if (cave.kind == CaveKind::TianTingCluster) {
                // 天庭洞天集群：规整聚落 + 灵脉
                t.terrain = n2 < 0.18 ? CaveTerrain::Settlement
                          : (n > 0.74 ? CaveTerrain::SpiritSpring
                          : (n < 0.24 ? CaveTerrain::MineVein : CaveTerrain::Floor));
            } else if (cave.kind == CaveKind::TaiguSevenFragment) {
                // 太古七天碎片：荒芜遗迹
                t.terrain = n > 0.70 ? CaveTerrain::Ruins
                          : (n2 < 0.15 ? CaveTerrain::ChaoticRift : CaveTerrain::Floor);
            } else {
                // 原著有名福地：灵田灵泉山岳俱全
                t.terrain = n < 0.26 ? CaveTerrain::SpiritField
                          : (n2 < 0.13 ? CaveTerrain::SpiritSpring
                          : (n > 0.68 ? CaveTerrain::Mountain
                          : (n2 > 0.88 ? CaveTerrain::MineVein : CaveTerrain::Floor)));
            }
        }
    }

    // 入口与出口
    //
    //  普通洞天：从下方进入（洞口在地图下缘）。
    //  大地裂缝则相反 —— 是从地表【往下】跳进去的，
    //  故入口与出口都在上缘（出口 = 爬回地表）。
    const bool crack = (cave.siteId.find("digou") != std::string::npos);
    if (crack) {
        f.entryX = f.w / 2; f.entryY = 2;
        // 若中轴处恰好是断壁，向两侧各让一格找一个可落之处
        if (f.inBounds(f.entryX, f.entryY) &&
            f.at(f.entryX, f.entryY).terrain == CaveTerrain::CrackWall) {
            for (int dx = 1; dx < f.w / 2; ++dx) {
                if (f.inBounds(f.entryX + dx, f.entryY) &&
                    f.at(f.entryX + dx, f.entryY).terrain != CaveTerrain::CrackWall) {
                    f.entryX += dx; break;
                }
                if (f.inBounds(f.entryX - dx, f.entryY) &&
                    f.at(f.entryX - dx, f.entryY).terrain != CaveTerrain::CrackWall) {
                    f.entryX -= dx; break;
                }
            }
        }
        f.exitX = f.entryX; f.exitY = 3;
    } else {
        f.entryX = f.w / 2; f.entryY = f.h - 3;
        f.exitX  = f.w / 2; f.exitY  = f.h - 2;
    }
    if (f.inBounds(f.entryX, f.entryY)) f.at(f.entryX, f.entryY).terrain = CaveTerrain::CaveEntrance;
    if (f.inBounds(f.exitX, f.exitY))   f.at(f.exitX, f.exitY).terrain  = CaveTerrain::CaveExit;

    // 原著定点（会覆盖入口出口之外的格子）
    placeCanonSites(f, cave, level);

    return { true, f.name };
}

// ---------------------------------------------------------------------------
//  整洞天生成
// ---------------------------------------------------------------------------
CaveRealmGenerator::Result CaveRealmGenerator::generate(CaveRealm& realm,
                                                        const CaveParadise& cave,
                                                        Rng& rng) {
    // 层数：九层结构依原著；其余单层
    int levels = 1;
    if (cave.siteId == "cn_fengmo_ku") levels = 9;
    // 地沟：深不见底，无人探到过沟底 —— 按原著「深达数百万丈」设为五层
    if (cave.siteId.find("digou") != std::string::npos) levels = 5;

    realm = CaveRealm(cave.siteId, cave.name, levels);

    //
    //  尺寸：福地小而精，洞天大而全。
    //
    //  新增：面积由【福地等级】决定 —— 下等最小、特等最大。
    //
    //  原著依据：福地分下/中/上/特四等，面积自三百万亩至两千万亩不等。
    //  面积越大，进去后的地图自然越大。此处把等级映射为格数：
    //    下等 48×36、中等 64×48、上等 96×72、特等 128×96。
    //
    //  注意：等级由【升仙纳气量】定，十绝体直取特等；
    //  并非甲乙丙丁资质映射（详见 CaveParadise.hpp 的口径澄清）。
    //
    const CaveGrade grade = cave.grade;
    const CaveGradeInfo gi = cave_grade_info(grade);

    const bool big = (cave.kind == CaveKind::TianTingCluster ||
                      cave.kind == CaveKind::HeavenDaoSecret ||
                      cave.siteId == "cn_fengmo_ku");
    // 地沟窄而深：口子不阔，向下深达数百万丈
    const bool crack = (cave.siteId.find("digou") != std::string::npos);

    int W, H;
    if (crack) { W = 40; H = 84; }
    else if (big) { W = 96; H = 72; }
    else { W = gi.mapW; H = gi.mapH; }

    for (int lv = 1; lv <= levels; ++lv) {
        CaveFloorMap& f = realm.floor(lv);
        f.w = W; f.h = H; f.level = lv;
        f.tiles.assign(static_cast<std::size_t>(W) * H, CaveTile{});
        auto r = genSingleFloor(f, cave, lv, levels, rng);
        if (!r.ok) return r;
    }

    // 初始位置：第一层入口
    CaveFloorMap& f0 = realm.floor(1);
    realm.setPos(1, f0.entryX, f0.entryY);
    f0.reveal(f0.entryX, f0.entryY, 5);
    realm.markGenerated();

    return { true, "秘境已生成：" + cave.name + "（" +
                   std::to_string(levels) + " 层，" +
                   std::to_string(W) + "×" + std::to_string(H) + "）" };
}

} // namespace gr
