// 天罡罡风状态机实现
#include "gr/world/Climate.hpp"

#include <algorithm>

namespace gr {

int TiangangGale::remain() const {
    switch (phase_) {
        case GalePhase::Calm:     return calmTicks - elapsed_;
        case GalePhase::Weak:     return weakTicks - elapsed_;
        case GalePhase::Disaster: return disasterTicks - elapsed_;
    }
    return 0;
}

bool TiangangGale::advance() {
    ++elapsed_;
    int limit = 0;
    switch (phase_) {
        case GalePhase::Calm:     limit = calmTicks;     break;
        case GalePhase::Weak:     limit = weakTicks;     break;
        case GalePhase::Disaster: limit = disasterTicks; break;
    }
    if (elapsed_ < limit) return false;

    // 轮换顺序：平静 → 弱风 → 暴风灾 → 平静 ……
    elapsed_ = 0;
    switch (phase_) {
        case GalePhase::Calm:     phase_ = GalePhase::Weak;     break;
        case GalePhase::Weak:     phase_ = GalePhase::Disaster; break;
        case GalePhase::Disaster: phase_ = GalePhase::Calm;     break;
    }
    return true;
}

void TiangangGale::reset(GalePhase p) { phase_ = p; elapsed_ = 0; }

bool TiangangGale::isLethalTo(Rank r) const {
    if (phase_ != GalePhase::Disaster) return false;
    return rank_value(r) < 8;   // 普通八转以下会被撕裂重创
}

double TiangangGale::traverseDifficulty() const {
    switch (phase_) {
        case GalePhase::Calm:     return 0.0;
        case GalePhase::Weak:     return 0.35;
        case GalePhase::Disaster: return 1.0;
    }
    return 0.0;
}

double TiangangGale::traverseCostMultiplier() const {
    switch (phase_) {
        case GalePhase::Calm:     return 1.0;
        case GalePhase::Weak:     return 2.0;
        case GalePhase::Disaster: return 6.0;
    }
    return 1.0;
}

} // namespace gr

// ---------------------------------------------------------------------------
//  两天洞天天灵状态
// ---------------------------------------------------------------------------
double TwoHeavensState::nodeDisruption() const {
    double d = 0.0;
    if (blackSpirit_ == HeavenSpiritState::Devoured) d += 0.40;
    else if (blackSpirit_ == HeavenSpiritState::Damaged) d += 0.20;
    else if (blackSpirit_ == HeavenSpiritState::Shattered) d += 0.30;

    if (whiteSpirit_ == HeavenSpiritState::Devoured) d += 0.35;
    else if (whiteSpirit_ == HeavenSpiritState::Damaged) d += 0.20;
    else if (whiteSpirit_ == HeavenSpiritState::Shattered) d += 0.30;

    if (sunNode_ != HeavenSpiritState::Intact) d += 0.25;
    return std::min(1.0, d);
}

std::string TwoHeavensState::describe() const {
    std::string s = "黑天天灵：" ;
    s += to_string(blackSpirit_);
    s += "，白天天灵：";
    s += to_string(whiteSpirit_);
    s += "，太阳天脉节点：";
    s += to_string(sunNode_);
    s += stable_ ? "（两天维持旧稳态）"
                 : "（旧稳态已破：幽魂吞噬黑天天灵后攻日，太阳爆裂，"
                   "两天洞天进入规则级重组）";
    return s;
}
