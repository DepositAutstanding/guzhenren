// 分块流式地图实现
//
//  核心取舍：地形【不落盘】，探索状态【落盘】。
//
//  地形由 seed 决定的噪声函数现算 —— 同一 seed 必得同一结果，
//  因此「不存」不等于「丢失」，且省下 78 万格的存储与 IO。
//  探索状态是玩家进度的唯一载体，必须持久化，故按块写外存。
#include "gr/world/CanonPlaces.hpp"
#include "gr/world/TileMap.hpp"

#include <algorithm>
#include <cmath>
#include <cstring>
#include <cstdio>
#include <sys/stat.h>

namespace gr {

// ---------------------------------------------------------------------------
//  噪声（纯函数，供分块现算）
// ---------------------------------------------------------------------------
namespace {

double hash2(int x, int y, std::uint32_t seed) {
    std::uint32_t h = seed;
    h ^= static_cast<std::uint32_t>(x) * 374761393u;
    h ^= static_cast<std::uint32_t>(y) * 668265263u;
    h = (h ^ (h >> 13)) * 1274126177u;
    return static_cast<double>((h ^ (h >> 16)) & 0xFFFF) / 65536.0;
}

double valueNoise(double x, double y, std::uint32_t seed) {
    const int xi = static_cast<int>(std::floor(x));
    const int yi = static_cast<int>(std::floor(y));
    const double xf = x - xi, yf = y - yi;
    const double u = xf * xf * (3.0 - 2.0 * xf);
    const double v = yf * yf * (3.0 - 2.0 * yf);
    const double a = hash2(xi,     yi,     seed);
    const double b = hash2(xi + 1, yi,     seed);
    const double c = hash2(xi,     yi + 1, seed);
    const double d = hash2(xi + 1, yi + 1, seed);
    const double x1 = a + (b - a) * u;
    const double x2 = c + (d - c) * u;
    return x1 + (x2 - x1) * v;
}

double fbm(double x, double y, std::uint32_t seed, int octaves = 4) {
    double sum = 0.0, amp = 1.0, freq = 1.0, norm = 0.0;
    for (int o = 0; o < octaves; ++o) {
        sum  += valueNoise(x * freq, y * freq, seed + o * 1013u) * amp;
        norm += amp;
        amp  *= 0.5;
        freq *= 2.0;
    }
    return sum / norm;
}

} // namespace

// ---------------------------------------------------------------------------
//  基础
// ---------------------------------------------------------------------------
void TileMap::setCacheDir(std::string dir) {
    cacheDir_ = std::move(dir);
    if (cacheDir_.empty()) return;

    // 须【逐級】创建：::mkdir("cache/tilemap") 在 "cache" 不存在时会直接失败，
    // 于是 saveChunkToDisk 的 fopen 也跟着失败，探索状态一个字节都写不出去 ——
    // 退出游戏后进度全丢，而界面上毫无异常。此处按路径分量逐级建目录。
    std::string acc;
    for (std::size_t i = 0; i <= cacheDir_.size(); ++i) {
        if (i == cacheDir_.size() || cacheDir_[i] == '/') {
            // Windows 的 mkdir 只接受一个参数，无权限位
            if (!acc.empty() && acc != "/") {
#ifdef _WIN32
                ::mkdir(acc.c_str());
#else
                ::mkdir(acc.c_str(), 0755);
#endif
            }
        }
        if (i < cacheDir_.size()) acc += cacheDir_[i];
    }
}

void TileMap::resize(int w, int h) {
    flush();
    w_ = w; h_ = h;
    resident_.clear(); lru_.clear(); lruPos_.clear();
    countedChunks_.clear();
    exploredTotal_ = 0;
    zones_.clear();
}

int TileMap::chunkCols() const { return (w_ + kChunk - 1) / kChunk; }
int TileMap::chunkRows() const { return (h_ + kChunk - 1) / kChunk; }

// ---------------------------------------------------------------------------
//  分块：LRU 管理
// ---------------------------------------------------------------------------
TileMap::Chunk& TileMap::touchChunk(int cid) const {
    auto it = resident_.find(cid);
    if (it != resident_.end()) {
        // 提到 LRU 头部
        lru_.erase(lruPos_[cid]);
        lru_.push_front(cid);
        lruPos_[cid] = lru_.begin();
        return it->second;
    }

    evictIfNeeded();

    // 新建并填充
    Chunk c;
    c.tiles.resize(static_cast<std::size_t>(kChunk) * kChunk);
    const int cx = cid % chunkCols(), cy = cid / chunkCols();
    buildChunk(c, cx, cy);

    // 若外存有探索记录则覆盖
    if (!cacheDir_.empty()) {
        Chunk disk;
        disk.tiles.resize(static_cast<std::size_t>(kChunk) * kChunk);
        if (loadChunkFromDisk(cid, disk)) {
            for (std::size_t i = 0; i < c.tiles.size(); ++i)
                c.tiles[i].explored = disk.tiles[i].explored;
            c.persisted = true;
        }

        // 探索度统计：每块只计一次。
        // 此前从外存载入的已探索格【不】计入 exploredTotal_，
        // 导致重新进入游戏后探索度显示为 0，而地图分明已探明大半。
        if (countedChunks_.find(cid) == countedChunks_.end()) {
            for (const Tile& t : c.tiles) if (t.explored) ++exploredTotal_;
            countedChunks_.insert(cid);
        }
    }

    auto [ins, ok] = resident_.emplace(cid, std::move(c));
    lru_.push_front(cid);
    lruPos_[cid] = lru_.begin();
    return ins->second;
}

void TileMap::evictIfNeeded() const {
    while (static_cast<int>(resident_.size()) >= kMaxResidentChunks && !lru_.empty()) {
        const int victim = lru_.back();
        lru_.pop_back();
        lruPos_.erase(victim);
        auto it = resident_.find(victim);
        if (it != resident_.end()) {
            if (it->second.dirty && !cacheDir_.empty())
                saveChunkToDisk(victim, it->second);
            resident_.erase(it);
        }
    }
}

// ---------------------------------------------------------------------------
//  块内地形：纯函数现算
// ---------------------------------------------------------------------------
void TileMap::buildChunk(Chunk& c, int cx, int cy) const {
    const int baseX = cx * kChunk, baseY = cy * kChunk;
    for (int j = 0; j < kChunk; ++j) {
        for (int i = 0; i < kChunk; ++i) {
            const int x = baseX + i, y = baseY + j;
            Tile& t = c.tiles[static_cast<std::size_t>(j) * kChunk + i];
            t = Tile{};
            if (x >= w_ || y >= h_) { t.terrain = Terrain::Void; continue; }
            SimpleMapGenerator::fillTile(t, x, y, w_, h_, seed_, zones_, this);

            //
            //  写回地标：块随时可能因 invalidateChunks 被重建，
            //  而 fillTile 并不知情。若不在此写回，
            //  此前 addLandmark 写入的 landmarkId 就被 Tile{} 抹掉了，
            //  地标在地图上「凭空消失」。
            //
            auto it = landmarkAtPos_.find(static_cast<std::int64_t>(y) * w_ + x);
            if (it != landmarkAtPos_.end()) {
                t.landmarkId = it->second;
                //
                //  原著固定地形【优先】于地标的地形覆盖。
                //  原著地形是「面」（苍莽草地横贯北原），地标是「点」
                //  （王庭福地落在其中某格）。若让地标把该格刷成 Landmark，
                //  苍莽草地这一格就不再是草原了 —— 与「原著有的地形
                //  必须在原著所述之处生成」相冲突。故只记 landmarkId，
                //  地形保留原样。
                //
                if (!t.canonZone && t.terrain != Terrain::Sea)
                    t.terrain = Terrain::Landmark;
            }
        }
    }
}

Tile& TileMap::at(int x, int y) {
    //
    //  边界检查 —— 此前完全缺失。
    //  x 为负时 C++ 整除向零取整：x=-1 → cx=0，而 i = -1 - 0 = -1，
    //  于是 c.tiles[j*kChunk - 1] 越界写堆（ASAN 实测 buffer-overflow）。
    //  玩家位置若因任何原因跑到界外，就会静默损坏内存。
    //
    if (!inBounds(x, y)) {
        //  返回一块哨兵格：写入不破坏堆，读取得到「虚空」。
        //  哨兵取静态存储期，生命周期与程序等长，引用不会悬垂。
        static Tile kOutOfBounds;
        kOutOfBounds = Tile{};
        kOutOfBounds.terrain = Terrain::Void;
        return kOutOfBounds;
    }
    const int cx = x / kChunk, cy = y / kChunk;
    Chunk& c = touchChunk(chunkId(cx, cy));
    const int i = x - cx * kChunk, j = y - cy * kChunk;
    return c.tiles[static_cast<std::size_t>(j) * kChunk + i];
}

const Tile& TileMap::at(int x, int y) const {
    return const_cast<TileMap*>(this)->at(x, y);
}

// ---------------------------------------------------------------------------
//  外存
// ---------------------------------------------------------------------------
std::string TileMap::chunkPath(int cid) const {
    return cacheDir_ + "/chunk_" + std::to_string(cid) + ".bin";
}

bool TileMap::loadChunkFromDisk(int cid, Chunk& c) const {
    const std::string p = chunkPath(cid);
    std::FILE* f = std::fopen(p.c_str(), "rb");
    if (!f) return false;
    // 位图：kChunk*kChunk bits
    const std::size_t bytes = static_cast<std::size_t>(kChunk) * kChunk / 8;
    std::vector<unsigned char> buf(bytes);
    const std::size_t got = std::fread(buf.data(), 1, bytes, f);
    std::fclose(f);
    if (got != bytes) return false;
    for (std::size_t i = 0; i < c.tiles.size(); ++i) {
        const bool bit = (buf[i >> 3] >> (i & 7)) & 1;
        c.tiles[i].explored = bit;
    }
    return true;
}

void TileMap::saveChunkToDisk(int cid, const Chunk& c) const {
    const std::string p = chunkPath(cid);
    std::FILE* f = std::fopen(p.c_str(), "wb");
    if (!f) return;
    const std::size_t bytes = static_cast<std::size_t>(kChunk) * kChunk / 8;
    std::vector<unsigned char> buf(bytes, 0);
    for (std::size_t i = 0; i < c.tiles.size(); ++i) {
        if (c.tiles[i].explored) buf[i >> 3] |= static_cast<unsigned char>(1u << (i & 7));
    }
    std::fwrite(buf.data(), 1, bytes, f);
    std::fclose(f);
}

void TileMap::flush() {
    for (auto& [cid, c] : resident_) {
        if (c.dirty && !cacheDir_.empty()) {
            saveChunkToDisk(cid, c);
            c.dirty = false;
        }
    }
}

void TileMap::recountFromDisk() {
    if (cacheDir_.empty()) return;
    exploredTotal_ = 0;
    countedChunks_.clear();
    for (int cy = 0; cy < chunkRows(); ++cy) {
        for (int cx = 0; cx < chunkCols(); ++cx) {
            const int cid = chunkId(cx, cy);
            std::FILE* f = std::fopen(chunkPath(cid).c_str(), "rb");
            if (!f) continue;
            const std::size_t bytes = static_cast<std::size_t>(kChunk) * kChunk / 8;
            std::vector<unsigned char> buf(bytes);
            const std::size_t got = std::fread(buf.data(), 1, bytes, f);
            std::fclose(f);
            if (got != bytes) continue;
            for (std::size_t i = 0; i < bytes * 8; ++i)
                if ((buf[i >> 3] >> (i & 7)) & 1) ++exploredTotal_;
            countedChunks_.insert(cid);
        }
    }
}

std::size_t TileMap::persistedChunkCount() const {
    if (cacheDir_.empty()) return 0;
    std::size_t n = 0;
    for (int cy = 0; cy < chunkRows(); ++cy)
        for (int cx = 0; cx < chunkCols(); ++cx) {
            std::FILE* f = std::fopen(chunkPath(chunkId(cx, cy)).c_str(), "rb");
            if (f) { std::fclose(f); ++n; }
        }
    return n;
}

// ---------------------------------------------------------------------------
//  生成
// ---------------------------------------------------------------------------
MapGenResult TileMap::generate(Rng& rng, IMapGenerator* gen) {
    SimpleMapGenerator builtin;
    IMapGenerator* g = gen ? gen : &builtin;
    genName_ = g->name();
    MapGenResult r = g->generate(*this, rng);
    generated_ = r.ok;
    // 骨架就绪后扫一遍外存，把上次存档的探索度补上，
    // 免得开局显示 0%、随走动才慢慢涨回来（像进度丢了一样）
    recountFromDisk();
    return r;
}

// ---------------------------------------------------------------------------
//  探索
// ---------------------------------------------------------------------------
bool TileMap::isExplored(int x, int y) const {
    if (!inBounds(x, y)) return false;
    return at(x, y).explored;
}

int TileMap::reveal(int cx, int cy, int r) {
    int newly = 0;
    for (int y = cy - r; y <= cy + r; ++y) {
        for (int x = cx - r; x <= cx + r; ++x) {
            if (!inBounds(x, y)) continue;
            const int dx = x - cx, dy = y - cy;
            if (dx * dx + dy * dy > r * r) continue;
            Tile& t = at(x, y);
            if (!t.explored) {
                t.explored = true;
                ++exploredTotal_;
                ++newly;
                // 标记所属块为脏，待写回外存
                const int cid = chunkId(x / kChunk, y / kChunk);
                auto it = resident_.find(cid);
                if (it != resident_.end()) it->second.dirty = true;
            }
        }
    }
    return newly;
}

void TileMap::revealAll() {
    for (int y = 0; y < h_; ++y)
        for (int x = 0; x < w_; ++x) {
            Tile& t = at(x, y);
            if (!t.explored) { t.explored = true; ++exploredTotal_; }
            auto it = resident_.find(chunkId(x / kChunk, y / kChunk));
            if (it != resident_.end()) it->second.dirty = true;
        }
    flush();
}

// ============================================================================
//  合并扫描
//
//  把「域占比、地类分布、探索度、地标域校验」四项并进同一次遍历。
//  四者都只读格子、互不干扰，本就该一起做 ——
//  分开跑等于把 315 万格扫四遍。
//
//  地标校验不采样：地标是定点，抽不到就漏检，故另行全量查点。
// ============================================================================
TileMap::MapScan TileMap::scanAll(int step, bool doLandmarkCheck) const {
    MapScan sc;
    if (step < 1) step = 1;
    if (w_ <= 0 || h_ <= 0) return sc;

    for (int y = 0; y < h_; y += step) {
        for (int x = 0; x < w_; x += step) {
            const Tile& t = at(x, y);
            ++sc.sampled;
            if (t.explored) ++sc.explored;
            const int d = static_cast<int>(t.domain);
            if (d >= 0 && d < 8) ++sc.byDomain[d];
            const int tr = static_cast<int>(t.terrain);
            if (tr >= 0 && tr < 64) ++sc.byTerrain[tr];
        }
    }
    int kinds = 0;
    for (int i = 0; i < 64; ++i) if (sc.byTerrain[i] > 0) ++kinds;
    sc.terrainKinds = kinds;

    if (doLandmarkCheck) {
        for (const auto& lm : landmarks_) {
            if (lm.x < 0 || lm.y < 0) continue;      // 无地表坐标
            if (!inBounds(lm.x, lm.y)) continue;
            ++sc.landmarkChecked;
            if (at(lm.x, lm.y).domain != lm.domain) ++sc.landmarkBad;
        }
    }
    return sc;
}

double TileMap::exploredRatio() const {
    if (w_ <= 0 || h_ <= 0) return 0.0;
    return static_cast<double>(exploredTotal_) /
           (static_cast<double>(w_) * h_);
}

// ---------------------------------------------------------------------------
//  地标
// ---------------------------------------------------------------------------
void TileMap::addLandmark(const Landmark& lm) {
    // 洞天内部 / 域外空间的地点【不】落在地表图上
    if (lm.kind != Landmark::Kind::Surface) { landmarks_.push_back(lm); return; }

    const std::int16_t id = static_cast<std::int16_t>(landmarks_.size());
    //
    //  域守卫：地表地标若落在别的域，就近投影回本域。
    //
    //  地图扩至 2048×1536、域界改不规则后，按旧相对坐标摆放的定点
    //  会落到邻域（白相洞天即是一例：声明南疆，落在中洲）。
    //  此前只做「跳过」，地标便凭空消失；改为螺旋就近搜索，
    //  既保证落在正确的域，也不丢条目。
    //
    if (lm.x >= 0 && lm.y >= 0 && inBounds(lm.x, lm.y) &&
        domainAt(lm.x, lm.y) != lm.domain) {
        int bx = lm.x, by = lm.y;
        bool found = false;
        for (int r = 1; r <= 400 && !found; ++r) {
            for (int dy = -r; dy <= r && !found; ++dy) {
                for (int dx = -r; dx <= r && !found; ++dx) {
                    if (std::max(std::abs(dx), std::abs(dy)) != r) continue;
                    const int nx = bx + dx, ny = by + dy;
                    if (!inBounds(nx, ny)) continue;
                    if (domainAt(nx, ny) != lm.domain) continue;
                    bx = nx; by = ny; found = true;
                }
            }
        }
        if (found) {
            const_cast<Landmark&>(lm).x = bx;
            const_cast<Landmark&>(lm).y = by;
        }
    }

    landmarks_.push_back(lm);
    if (inBounds(lm.x, lm.y)) {
        //  记入坐标表 —— 块失效重建后据此写回，否则地标会凭空消失
        landmarkAtPos_[static_cast<std::int64_t>(lm.y) * w_ + lm.x] = id;
        Tile& t = at(lm.x, lm.y);
        t.landmarkId = id;
        //  同上：落在本格的地标不覆盖原著固定地形
        if (!t.canonZone && t.terrain != Terrain::Sea) t.terrain = Terrain::Landmark;
    }
}

const Landmark* TileMap::landmarkAt(int x, int y) const {
    if (!inBounds(x, y)) return nullptr;
    const std::int16_t id = at(x, y).landmarkId;
    if (id < 0 || static_cast<std::size_t>(id) >= landmarks_.size()) return nullptr;
    return &landmarks_[id];
}

const Landmark* TileMap::landmarkById(const std::string& id) const {
    for (const auto& lm : landmarks_) if (lm.id == id) return &lm;
    return nullptr;
}

Domain TileMap::domainAt(int x, int y) const {
    if (!inBounds(x, y)) return Domain::None;
    return at(x, y).domain;
}

// ---------------------------------------------------------------------------
//  简易生成器
// ---------------------------------------------------------------------------
// 区域「面积」：用于判定具体程度。
// 大区域（如整个西漠沙漠）会连小区域（天露绿洲、怎渡丘）一起罩住，
// 若按登记顺序取第一个命中，绿洲就被沙漠吞了 —— 故取【最小】的命中区，
// 越具体的地形优先级越高。
namespace {
double canonZoneArea(const CanonTerrainZone& z) {
    if (z.shape == CanonShape::Rect)
        return (z.x1 - z.x0) * (z.y1 - z.y0);
    const double vx = z.bx - z.ax, vy = z.by - z.ay;
    const double len = std::sqrt(vx * vx + vy * vy);
    return len * 2.0 * z.halfWidth;
}
} // namespace

const CanonTerrainZone* TileMap::canonZoneAt(int x, int y) const {
    if (w_ <= 0 || h_ <= 0) return nullptr;
    const double fx = static_cast<double>(x) / w_;
    const double fy = static_cast<double>(y) / h_;

    const CanonTerrainZone* best = nullptr;
    double bestArea = 0.0;
    for (const auto& z : canonZones_) {
        bool hit = false;
        if (z.shape == CanonShape::Rect) {
            hit = (fx >= z.x0 && fx < z.x1 && fy >= z.y0 && fy < z.y1);
        } else {
            // 点到线段距离
            const double vx = z.bx - z.ax, vy = z.by - z.ay;
            const double wx = fx - z.ax,   wy = fy - z.ay;
            const double len2 = vx * vx + vy * vy;
            double t = (len2 > 1e-12) ? (wx * vx + wy * vy) / len2 : 0.0;
            t = std::clamp(t, 0.0, 1.0);
            const double px = z.ax + vx * t, py = z.ay + vy * t;
            const double dx = fx - px, dy = fy - py;
            hit = (dx * dx + dy * dy <= z.halfWidth * z.halfWidth);
        }
        if (!hit) continue;
        const double a = canonZoneArea(z);
        if (!best || a < bestArea) { best = &z; bestArea = a; }
    }
        //
    //  覆写型区域优先：事件改变了地貌（如青茅山化为冰域），
    //  应盖过原本的自然地物，不受「面积最小优先」约束。
    //
    if (best && !best->overlay) {
        const CanonTerrainZone* ov = nullptr;
        double ovArea = 0.0;
        for (const auto& z : canonZones_) {
            if (!z.overlay) continue;
            bool hit = false;
            if (z.shape == CanonShape::Rect) {
                hit = (fx >= z.x0 && fx < z.x1 && fy >= z.y0 && fy < z.y1);
            } else {
                const double vx = z.bx - z.ax, vy = z.by - z.ay;
                const double wx = fx - z.ax,   wy = fy - z.ay;
                const double len2 = vx * vx + vy * vy;
                double t = (len2 > 1e-12) ? (wx * vx + wy * vy) / len2 : 0.0;
                t = std::clamp(t, 0.0, 1.0);
                const double px = z.ax + vx * t, py = z.ay + vy * t;
                const double dx = fx - px, dy = fy - py;
                hit = (dx * dx + dy * dy <= z.halfWidth * z.halfWidth);
            }
            if (!hit) continue;
            const double a = canonZoneArea(z);
            if (!ov || a < ovArea) { ov = &z; ovArea = a; }
        }
        if (ov) return ov;
    }
    return best;
}

void TileMap::invalidateChunks() {
    resident_.clear();
    lru_.clear();
    lruPos_.clear();
    countedChunks_.clear();
    exploredTotal_ = 0;
}


// ===========================================================================
//  大地貌起伏（需求 10）
// ===========================================================================
Terrain reliefSubTerrain(Terrain base, double e) {
    //
    //  阈值依实测 fbm 分位标定：p82≈0.644 p37≈0.447 p09≈0.308，
    //  故按 峰 18% / 坡 45% / 谷 28% / 涧 9% 切分。
    //
    //  细化地形图后，山系内部也做垂直分带 —— 由山脚到山顶依次为
    //  丘陵 → 山麓 → 山坡 → 高峰 → 雪峰，一片大山才有层次感。
    switch (base) {
        case Terrain::Mountain:
            if      (e >= 0.88)  return Terrain::SnowPeak;   // 雪线以上
            else if (e >= 0.644) return Terrain::Mountain;   // 山脊高峰
            else if (e >= 0.500) return Terrain::Foothill;   // 山坡
            else if (e >= 0.447) return Terrain::Hill;       // 山麓丘陵
            else if (e >= 0.308) return Terrain::Plain;      // 山谷 / 山间平地
            return Terrain::Water;                           // 山涧 / 山中湖

        case Terrain::Desert:
            if      (e >= 0.644) return Terrain::SandDune;
            else if (e >= 0.500) return Terrain::Gobi;       // 砾石戈壁
            else if (e >= 0.308) return Terrain::Desert;
            return Terrain::Oasis;

        case Terrain::Grassland:
            if      (e >= 0.780) return Terrain::SnowPeak;
            else if (e >= 0.644) return Terrain::Grassland;
            else if (e >= 0.500) return Terrain::Hill;
            else if (e >= 0.308) return Terrain::Grassland;
            return Terrain::Water;                           // 草原湖泡

        case Terrain::IceField:
            if      (e >= 0.880) return Terrain::SnowPeak;
            else if (e >= 0.644) return Terrain::IceField;
            else if (e >= 0.308) return Terrain::IceField;
            return Terrain::Water;                           // 冰裂融水

        case Terrain::ToxicForest:
            if      (e >= 0.700) return Terrain::Mountain;
            else if (e >= 0.500) return Terrain::ToxicForest;
            else if (e >= 0.308) return Terrain::ToxicForest;
            return Terrain::Wetland;                         // 毒泽

        case Terrain::Rainforest:
            if      (e >= 0.700) return Terrain::Forest;
            else if (e >= 0.500) return Terrain::Rainforest;
            else if (e >= 0.308) return Terrain::Rainforest;
            return Terrain::Water;

        default:
            //  江河、海域、界壁等本就是单一地貌，不再细分
            return base;
    }
}

bool isReliefVariantOf(Terrain actual, Terrain base) {
    if (actual == base) return true;
    switch (base) {
        case Terrain::Mountain:
            //  山系内部由山脚到山顶的整套垂直分带，都属这片山
            return actual == Terrain::SnowPeak  || actual == Terrain::Foothill ||
                   actual == Terrain::Hill      || actual == Terrain::Plain ||
                   actual == Terrain::Water     || actual == Terrain::Forest;
        case Terrain::Desert:
            return actual == Terrain::SandDune || actual == Terrain::Oasis ||
                   actual == Terrain::Gobi;
        case Terrain::Grassland:
            return actual == Terrain::SnowPeak || actual == Terrain::Hill ||
                   actual == Terrain::Water;
        case Terrain::IceField:
            return actual == Terrain::SnowPeak || actual == Terrain::Water;
        case Terrain::ToxicForest:
            return actual == Terrain::Mountain || actual == Terrain::Wetland;
        case Terrain::Rainforest:
            return actual == Terrain::Forest  || actual == Terrain::Water;
        default:
            return false;
    }
}


// ===========================================================================
//  域界：极坐标不规则划分
//
//  地理研究第三节（A 级）：
//    「东面是东海，西面是西漠，北面是北原，南面是南疆，四者包拢中洲。」
//    「『四周一中心』是可靠邻接骨架，但五域并非规整同心方块。」
//
//  此前的实现是【矩形拼接】（中洲居中矩形＋四域环围矩形），
//  结果是规整的十字形：四个角落留空、各域面积趋同 ——
//  恰恰是研究报告明确拒绝的「规整同心方块 / 等大方块」。
//
//  现改为极坐标划分：中洲为不规则内圈，四域为不规则外圈扇区，
//  半径与分界角都做多重噪声扰动，故域界是弯曲的、各域面积不等。
//
//  另一处修正：矩形分区的「界壁」= 到矩形边的距离，
//  而界壁实为【域与域之间的空间摩擦力】，应沿域界生成，
//  不是沿着某个矩形的边。
// ===========================================================================
namespace {

struct PolarDomain {
    Domain dom        = Domain::None;
    double borderDist = 1e9;   // 到最近域界的近似距离（格）
};

PolarDomain polarDomainAt(int x, int y, int W, int H, std::uint32_t seed) {
    static const double PI = 3.14159265358979323846;

    const double cx = W * 0.5, cy = H * 0.5;
    const double nx = (x - cx) / (W * 0.5);
    const double ny = (y - cy) / (H * 0.5);
    const double r  = std::sqrt(nx * nx + ny * ny);
    const double th = std::atan2(ny, nx);       // 屏幕坐标：y 向下为正

    //  相位随种子变化，使不同存档的世界形状不同，但结构一致
    const double s1 = static_cast<double>(seed % 97) * 0.0613;
    const double s2 = static_cast<double>(seed % 53) * 0.1127;

    //
    //  中洲核心半径随方位起伏。
    //  倍频取整数以保证 θ 绕一圈后连续（否则 θ=π 与 -π 处会裂开）。
    //
    const double R0 = 0.48;
    //
    //  三个正弦在南向（θ=π/2）恰好同相取正，使中洲被推得过分偏南：
    //  实测南向半径 0.677、北向仅 0.295，中洲拖出一条长半岛压进南疆，
    //  把十万大山与三江的上游段挤到中洲一侧。
    //  故加一项方位补偿：南向（sin θ=+1）收缩、北向（sin θ=-1）外扩，
    //  使中洲回到中央，南疆得以完整。
    //
    const double lean = 1.0 - 0.35 * std::sin(th);
    const double rCore = R0 * lean * (1.0
        + 0.24 * std::sin(3.0 * th + 1.7 + s1)
        + 0.14 * std::sin(5.0 * th + 0.4 + s2)
        + 0.08 * std::sin(7.0 * th + 2.9));

    const double dr = std::fabs(r - rCore);
    const double scale = W * 0.5;               // 归一化 → 格

    if (r < rCore) return { Domain::ZhongZhou, dr * scale };

    //
    //  外圈四域：分界角同样扰动。
    //  基准分界：  π/4（东|南）、3π/4（南|西）、-3π/4（西|北）、-π/4（北|东）
    //  四扇区宽度略作不等 —— 研究报告明言「五域不是等大方块」，
    //  但具体面积比例原著数据互相矛盾（北原「八万多亿亩」
    //  对南疆「七八个地球总面积」），无可确证值，故此处为工程构造。
    //
    const double thWarp = th
        + 0.18 * std::sin(2.0 * th + 0.9 + s1)
        + 0.10 * std::sin(4.0 * th + 2.1 + s2);

    double a = thWarp;
    while (a < -PI) a += 2.0 * PI;
    while (a >= PI) a -= 2.0 * PI;

    //  分界角（略作不等，避免四域等分）
    //
    //  扇区角宽须补偿地图宽高比：地图 1024×768 横长纵短，
    //  若按等角宽切分，左右（东海/西漠）会吃到远多于上下（南疆/北原）的
    //  面积 —— 实测一度出现东西合计 64%、南北仅 23%。
    //  故左右扇区收窄、上下扇区放宽。
    //
    const double bES = PI * 0.21;      // 东|南
    const double bSW = PI * 0.79;      // 南|西
    const double bWN = -PI * 0.79;     // 西|北
    const double bNE = -PI * 0.21;     // 北|东

    double minAng = 1e9;
    for (double b : {bES, bSW, bWN, bNE}) {
        double d = std::fabs(a - b);
        if (d > PI) d = 2.0 * PI - d;
        if (d < minAng) minAng = d;
    }

    Domain d;
    if      (a >= bNE && a < bES) d = Domain::DongHai;    // 右：东海
    else if (a >= bES && a < bSW) d = Domain::NanJiang;   // 下：南疆
    else if (a >= bSW || a < bWN) d = Domain::XiMo;       // 左：西漠
    else                          d = Domain::BeiYuan;    // 上：北原

    //  到域界的距离：扇区分界（弧长）与中洲边界，取近者
    const double borderAng = minAng * r * scale;
    return { d, std::min(borderAng, dr * scale) };
}

} // namespace

// ---------------------------------------------------------------------------
//  区域边缘羽化权重
//
//  返回 0~1：0 = 紧贴边界，1 = 深入区内（距边界已超过羽化宽度）。
//
//  用途：消除地形区边界的【直线断层】。区域是矩形或带状，
//  边界在数学上是直线；若区内一律甲地形、区外一律乙地形，
//  地图上就会出现一条笔直的硬切线。真实地貌之间是渐变交错的。
//
//  羽化宽度取区域尺度的 6%，并夹在 3~24 格之间。
// ---------------------------------------------------------------------------
static double canon_zone_feather(const CanonTerrainZone& z,
                                 int x, int y, int W, int H) {
    const double fx = static_cast<double>(x) / static_cast<double>(W ? W : 1);
    const double fy = static_cast<double>(y) / static_cast<double>(H ? H : 1);

    //  到边界的距离（相对坐标），负值表示在区外
    double dist;      // 到最近边界的相对距离
    double scale;     // 区域尺度，用于定羽化宽度
    double inradius;  // 内切半径：区域中心到边界的最大距离

    if (z.shape == CanonShape::Rect) {
        dist = std::min({ std::fabs(fx - z.x0), std::fabs(z.x1 - fx),
                          std::fabs(fy - z.y0), std::fabs(z.y1 - fy) });
        const double rw = std::fabs(z.x1 - z.x0), rh = std::fabs(z.y1 - z.y0);
        scale    = std::min(rw, rh);
        inradius = std::min(rw, rh) * 0.5;
    } else {
        //  Band：到线段所在直线的距离，并考虑两端
        const double vx = z.bx - z.ax, vy = z.by - z.ay;
        const double wx = fx - z.ax,   wy = fy - z.ay;
        const double len2 = vx * vx + vy * vy;
        double tt = (len2 > 0.0) ? (wx * vx + wy * vy) / len2 : 0.0;
        tt = std::clamp(tt, 0.0, 1.0);
        const double px = z.ax + vx * tt, py = z.ay + vy * tt;
        const double dLine = std::hypot(fx - px, fy - py);
        const double dEnds = std::min(std::hypot(wx, wy),
                                      std::hypot(fx - z.bx, fy - z.by));
        dist = z.halfWidth - std::max(dLine, 0.0);
        //  两端之外也算边界
        dist = std::min(dist, std::hypot(fx - px, fy - py) * 0.0 + dist);
        (void)dEnds;
        scale    = std::max(z.halfWidth * 2.0, std::hypot(vx, vy));
        inradius = z.halfWidth;      // 带状区域最深处就是半宽
    }

    if (dist <= 0.0) return 0.0;

    //
    //  羽化宽度：区域尺度的 6%，夹在 3~24 格（换算为相对距离）。
    //
    //  【关键约束】羽化不能吞掉整个区域。
    //
    //  对窄带区域（如碧龙江，半宽仅 0.007）而言，尺度（线段长度）
    //  远大于半宽，若按尺度取 6% 作羽化宽度（约 0.013），
    //  羽化带就比区域本身还宽 —— 区域中心也在羽化范围内，
    //  于是「区内地形」在中心处都可能被噪声否决，
    //  碧龙江的中轴线便不再保证是水（实测随机翻车）。
    //
    //  故羽化宽度再受【内切半径的 80%】约束：
    //  中心距边界恰为内切半径，除 0.8 倍得 1.25，clamp 后为 1，
    //  即中心必定保留区内地形，羽化只发生在真正的边缘。
    //
    double fw = scale * 0.06;
    const double minFw = 3.0 / static_cast<double>(W ? W : 1);
    const double maxFw = 24.0 / static_cast<double>(W ? W : 1);
    fw = std::clamp(fw, minFw, maxFw);
    fw = std::min(fw, inradius * 0.8);
    if (fw <= 0.0) return 1.0;       // 区域过窄，不羽化

    return std::clamp(dist / fw, 0.0, 1.0);
}

void SimpleMapGenerator::fillTile(Tile& t, int x, int y,
                                  int W, int H, std::uint32_t seed,
                                  const std::vector<TileMap::Zone>& zones,
                                  const TileMap* map) {
    (void)W;   // 宽度仅北原冷量计算用到 H
    (void)zones;   // 域界已改为极坐标不规则划分（见 polarDomainAt），矩形 zones 不再参与

    //
    //  分区判定：极坐标不规则域界
    //
    const PolarDomain pd = polarDomainAt(x, y, W, H, seed);
    Domain dom = pd.dom;
    int borderDist = static_cast<int>(pd.borderDist);

    //  地图最外缘 = 世界胎壁（玩家永不可突破），与域间界壁性质不同
    const int edgeDist = std::min({ x, y, W - 1 - x, H - 1 - y });

    t.domain = dom;
    if (dom == Domain::None) { t.terrain = Terrain::Void; t.elevation = 0; return; }

    // —— 原著固定地形优先于噪声 ——
    // 原著载明的地形必须在固定地点生成；若交给噪声，
    // 落天河可能长成草原、十万大山可能变成平川，与原著直接冲突。
    //
    //  高程一律用【同一套噪声】取，不论该格是否落在原著固定区内。
    //
    //  此前区内另用一套（频率 0.02、3 阶），区外用（0.018、4 阶），
    //  两者是不同的高程场 —— 区域边界处高程不连续，
    //  地图上便出现沿矩形/带状边界的【直线断层】。
    //  统一后高程处处连续，断层只剩地形类型的切换。
    //
    const double n  = fbm(x * 0.018, y * 0.018, seed, 4);
    const double n2 = fbm(x * 0.045 + 51.7, y * 0.045 + 23.1, seed + 7777u, 3);
    t.elevation = static_cast<std::uint8_t>(std::clamp(n * 255.0, 0.0, 255.0));

    if (const CanonTerrainZone* cz = map ? map->canonZoneAt(x, y) : nullptr) {
        //
        //  需求 10：山一类的大范围地貌须按现有比例生成起伏，
        //  而不是把整片固定区铺成一块同色死板。
        //  原著的「十万大山」指的是这片山系，山系内部本就有峰、坡、谷、涧；
        //  故此处依高程切分亚型，仍标记 canonZone=true 表明归属该固定区。
        //
        //  【断层修复】区域边界羽化。
        //
        //  区域是矩形/带状，边界是数学上的直线。若区内一律甲地形、
        //  区外一律乙地形，边界就是一条笔直的硬切线 ——
        //  这正是地图上「断层」的来源，且极不自然：
        //  真实的草原与沙漠之间是渐变交错的，不是刀切的。
        //
        //  故在边界内侧一段宽度内，按噪声抖动决定用区内地形还是基础地形，
        //  使交界呈犬牙交错状。羽化宽度取区域尺度的 6%，
        //  且不小于 3 格、不大于 24 格 —— 太小看不出效果，太大则区域失真。
        //
        //  羽化权重 w：0 = 紧贴边界，1 = 深入区内
        const double w = canon_zone_feather(*cz, x, y, W, H);
        //  边界处（w 小）只有少数格保留区内地形，越往里越必定保留
        const bool keepZone = (w >= 1.0) || (n2 < w) || cz->overlay;

        if (keepZone) {
            t.terrain   = reliefSubTerrain(cz->terrain, n);
            t.domain    = cz->domain != Domain::None ? cz->domain : dom;
            t.canonZone = true;
            return;
        }
        //  否则落到下方通用分带逻辑 —— 交界因此呈犬牙交错，而非直线
    }
    // e = 归一化高程（0..1），垂直分带一律以此为准，避免各处混用 n 与 elevation
    const double e = std::clamp(n, 0.0, 1.0);

    //
    //  界壁带：沿【域界】生成，而非沿某个矩形的边。
    //  地理研究（A 级）：五域各有一套界壁，是「域与域之间的空间摩擦力」，
    //  对本域引力、外域斥力，层次越高阻碍越强。
    //
    if (borderDist <= 3) { t.terrain = Terrain::Wall; return; }
    //  最外缘：世界胎壁
    if (edgeDist <= 2) { t.terrain = Terrain::Wall; return; }

    //
    //  细化地形图：不再「一个域三五个硬阈值一刀切」，
    //  而是【区域底色 × 垂直分带】两层叠加 ——
    //    ① 先由 n2（高频噪声）定区域底色（林、瘴、沙、脉……）
    //    ② 再由 e（高程）做垂直分带：雪线 → 高峰 → 山麓 → 丘陵 → 平地 → 水
    //  同一域内也有了由低到高的层次，地类从每域 4~5 种增至 8~10 种。
    //
    switch (dom) {
        case Domain::ZhongZhou:
            // 中洲：元气最盛，山川平原河川交错，灵脉密集
            if      (n2 < 0.14)  t.terrain = Terrain::Abyss;
            else if (n2 > 0.86)  t.terrain = Terrain::SpiritVein;   // 地理研究：中洲灵脉密集
            else if (e > 0.88)   t.terrain = Terrain::SnowPeak;
            else if (e > 0.70)   t.terrain = Terrain::Mountain;
            else if (e > 0.60)   t.terrain = Terrain::Foothill;
            else if (e > 0.50)   t.terrain = Terrain::Hill;
            else if (e > 0.42)   t.terrain = (n2 > 0.62) ? Terrain::Forest : Terrain::Plain;
            else if (e > 0.36)   t.terrain = (n2 > 0.74) ? Terrain::Lake : Terrain::Plain;
            else if (e > 0.30)   t.terrain = Terrain::Wetland;
            else                 t.terrain = Terrain::Water;
            break;

        case Domain::BeiYuan:
        {
            // 北原：越北越冷；草原为底，北部冰原
            const double cold = (1.0 - static_cast<double>(y) / std::max(1, H / 3)) * 0.42 + e * 0.58;
            if      (cold > 0.78)         t.terrain = Terrain::SnowPeak;
            else if (cold > 0.68)         t.terrain = Terrain::IceField;
            else if (n2 < 0.26)           t.terrain = Terrain::Water;
            else if (e > 0.66)            t.terrain = Terrain::Mountain;
            else if (e > 0.58)            t.terrain = Terrain::Foothill;
            else if (e > 0.50)            t.terrain = Terrain::Hill;
            else if (e > 0.42)            t.terrain = Terrain::Grassland;
            else if (e > 0.36)            t.terrain = (n2 > 0.70) ? Terrain::Lake : Terrain::Grassland;
            else                          t.terrain = Terrain::Wetland;
            break;
        }

        case Domain::NanJiang:
            // 南疆：十万大山连绵，三江贯穿，瘴气雨林
            if      (e > 0.88)   t.terrain = Terrain::SnowPeak;
            else if (e > 0.62)   t.terrain = Terrain::Mountain;
            else if (e > 0.54)   t.terrain = Terrain::Foothill;
            else if (e > 0.46)   t.terrain = Terrain::Hill;
            else if (n2 < 0.22)  t.terrain = Terrain::ToxicForest;
            else if (n2 > 0.86)  t.terrain = Terrain::Rainforest;
            else if (e > 0.38)   t.terrain = (n2 > 0.58) ? Terrain::Forest : Terrain::Plain;
            else if (e > 0.32)   t.terrain = (n2 > 0.72) ? Terrain::Lake : Terrain::Wetland;
            else                 t.terrain = Terrain::Water;
            break;

        case Domain::XiMo:
            // 西漠：戈壁大漠与移动沙丘，绿洲点缀
            if      (e > 0.68)   t.terrain = Terrain::Mountain;      // 万矿戈壁
            else if (e > 0.60)   t.terrain = Terrain::Foothill;
            else if (e > 0.52)   t.terrain = Terrain::Gobi;
            else if (n2 < 0.11)  t.terrain = Terrain::Oasis;
            else if (e > 0.44 && n2 > 0.80) t.terrain = Terrain::SandDune;
            else if (e > 0.40)   t.terrain = Terrain::Desert;
            else if (e > 0.34)   t.terrain = (n2 > 0.68) ? Terrain::Lake : Terrain::Desert;
            else                 t.terrain = Terrain::Gobi;          // 低地盐碱砾石
            break;

        case Domain::DongHai:
            // 东海：以海域划分，群岛星罗，海底潜流纵横
            if      (e > 0.62)   t.terrain = Terrain::Island;
            else if (e > 0.565)  t.terrain = Terrain::Shoal;         // 浅滩
            else if (e > 0.540)  t.terrain = Terrain::Coast;         // 海岸
            else if (n2 < 0.18)  t.terrain = Terrain::Undercurrent;  // 海底潜流航路
            else                 t.terrain = Terrain::Sea;
            break;

        default: t.terrain = Terrain::Plain; break;
    }
}

MapGenResult SimpleMapGenerator::generate(TileMap& map, Rng& rng) {
    const int W = map.width(), H = map.height();
    if (W < 64 || H < 64) return { false, "地图尺寸过小（至少 64×64）" };

    const std::uint32_t seed = static_cast<std::uint32_t>(rng.rangeInt(1, 1000000));
    map.setSeed(seed);

    // ------------------------------------------------------------------
    //  ① 分区骨架：四环围一中心（各域尺寸刻意不等，交界留白为界壁）
    // ------------------------------------------------------------------
    std::vector<TileMap::Zone> zones;
    const int zx0 = static_cast<int>(W * 0.34), zx1 = static_cast<int>(W * 0.66);
    const int zy0 = static_cast<int>(H * 0.34), zy1 = static_cast<int>(H * 0.66);
    zones.push_back({Domain::ZhongZhou, zx0, zy0, zx1, zy1});
    zones.push_back({Domain::BeiYuan,   zx0 - W / 7, 0,           zx1 + W / 7, zy0});
    zones.push_back({Domain::NanJiang,  zx0 - W / 7, zy1,         zx1 + W / 7, H});
    zones.push_back({Domain::XiMo,      0,           zy0 - H / 7, zx0,         zy1 + H / 7});
    zones.push_back({Domain::DongHai,   zx1,         zy0 - H / 7, W,           zy1 + H / 7});
    map.setZones(zones);

    // ------------------------------------------------------------------
    //  ② 地标：依地理研究第五节「著名地点清单」定点放置
    //
    //     关键约束 —— 地点分四类，仙窍内部与域外空间【不】落在地表图上：
    //       荡魂山 / 落魄谷 → 琅琊福地内部（InsideCave）
    //       逆流河         → 至尊仙窍「小东海」（InsideCave）
    //       光阴长河       → 宙道域外规则空间（OuterRule）
    //       天庭洞天 / 监天塔 / 长生天 / 白相洞天 → 五域上方两天（TwoHeavens）
    //     这些仍登记入表（供查询与后续层级扩展），但不占地表格子。
    // ------------------------------------------------------------------
    using LK = Landmark::Kind;
    auto put = [&](const char* id, const char* name, const char* desc,
                   Domain dom, double fx, double fy,
                   const char* siteId, const char* source, bool canon,
                   LK kind = LK::Surface, bool ruined = false) {
        Landmark lm;
        lm.id = id; lm.name = name; lm.desc = desc;
        lm.domain = dom;
        lm.x = (fx < 0.0) ? -1 : static_cast<int>(W * fx);
        lm.y = (fy < 0.0) ? -1 : static_cast<int>(H * fy);
        lm.siteId = siteId ? siteId : "";
        lm.source = source; lm.canon = canon; lm.kind = kind;
        lm.ruined = ruined;
        map.addLandmark(lm);
    };

    // —— 中洲（A 级）——
    put("lingyuanzhai", "灵缘斋", "中洲十大古派之一，正道核心势力",
        Domain::ZhongZhou, 0.42, 0.40, "", "地理研究：中洲十大古派", true);
    put("feiheshan", "飞鹤山", "中洲南部群山、云海，三万丈以上高空悬山福地",
        Domain::ZhongZhou, 0.46, 0.60, "", "地理研究：中洲·飞鹤山", true);
    put("luotianhe", "落天河", "中洲大川之一，证明中洲并非只有平原",
        Domain::ZhongZhou, 0.38, 0.52, "", "地理研究：中洲·落天河", true);
    put("guanhe", "罐河", "中洲大川，与落天河同为贯通水系",
        Domain::ZhongZhou, 0.44, 0.36, "", "地理研究：中洲·罐河", true);
    put("diyuan", "地渊", "深不见底的中洲深渊",
        Domain::ZhongZhou, 0.55, 0.55, "", "地理研究：中洲·地渊", true);
    put("shidagupai", "十大古派", "分布于中洲各地，天庭之下的秩序骨架",
        Domain::ZhongZhou, 0.50, 0.38, "", "地理研究：中洲·十大古派", true);

    // —— 中洲上方·白天（不占地表格子）——
    put("tiantingdongtian", "天庭洞天", "由历代八转洞天归并而成，吞有大量太古七天碎片；"
        "宿命破碎后监天塔粉碎、体系崩坏",
        Domain::ZhongZhou, 0.50, 0.50, "cn_tianting", "地理研究：天庭洞天", true, LK::TwoHeavens);
    //  帝君城：第五卷末宿命蛊摧毁后，此处生出一道新的地沟并向外蔓延。
    //  注意：这道地沟是【五域地脉融合所致的个案】，
    //  与「地沟天然形成」的普遍规律不冲突 —— 前者是因，后者是常态。
    put("dijuncheng", "帝君城", "中洲大城，第五卷末宿命蛊摧毁后城中裂开新的地沟",
        Domain::ZhongZhou, 0.55, 0.52, "", "地理研究：帝君城地沟（个案）", true);
    put("jiantianta", "监天塔", "天庭洞天中央，九转仙蛊屋，侦查范围覆盖五域与两天；"
        "宿命蛊破碎后裂纹扩散、崩碎坠落",
        Domain::ZhongZhou, 0.50, 0.50, "cn_jiantianta", "地理研究：监天塔", true, LK::TwoHeavens);

    // —— 北原（A 级）——
    put("wangtingfudi", "王庭福地", "北原权力核心，承担长生天的灾劫排遣功能；"
        "赢得王庭之争的部族可进入避灾",
        Domain::BeiYuan, 0.50, 0.12, "cn_wangting_fudi", "地理研究：北原·王庭福地", true);
    put("fengmoku", "疯魔窟", "北原十大凶地之一，九层嵌套：外层雨林、二层火岩石滩、"
        "三层云竹雾都猛兽、九层元境书山疯魔九虚阵。无极魔尊为推衍天道所造",
        Domain::BeiYuan, 0.36, 0.20, "cn_fengmo_ku", "地理研究：北原·疯魔窟", true);
    put("bingchaichuan", "冰塞川", "北原冰原地带，第六卷仍在展开的政治地理变量",
        Domain::BeiYuan, 0.62, 0.08, "", "地理研究：北原（B 级）", false);
    put("yueyahu", "月牙湖", "琅琊福地原址所在（影宗突袭后迁址，第六卷时已不在原址）",
        Domain::BeiYuan, 0.30, 0.15, "", "地理研究：北原·月牙湖", true);
    put("changshengtian", "长生天", "巨阳体系的最高权力中心，北原上方位的超级洞天体系",
        Domain::BeiYuan, 0.50, 0.05, "cn_changshengtian", "地理研究：北原·长生天", true, LK::TwoHeavens);
    //  阴流巨城：僵盟为霸占北原地沟而建
    put("yinliujucheng", "阴流巨城", "僵盟所据巨城，为霸占北原地沟而建",
        Domain::BeiYuan, 0.40, 0.20, "", "地理研究：北原·阴流巨城", true);

    // —— 南疆（A 级）——
    //
    //  青茅山：第六卷时间线【已毁】，不可作为出生点。
    //
    //  第一卷青茅山大决战，白凝冰自爆北冥冰魄体：
    //    「冰川四处扩张，竟然覆盖了整个青茅山，从山顶到山脚，
    //      在顷刻之间就将原本郁郁葱葱、生机勃勃的青茅山
    //      化为一片冰霜风雪的险恶之地。」
    //  方源前世（五百年前）亦载：白凝冰空窍不堪重负轰然自爆，
    //    「直接将三寨中人全部杀死，将整个青茅山都化为绝死冰域」。
    //
    //  故此处标 ruined=true，地形为冰原，地名注明「冰域绝地」。
    //
    put("qingmaoshan", "青茅山（冰域绝地）",
        "原著第一卷白凝冰自爆北冥冰魄体，冰川自山顶覆盖至山脚，"
        "青茅山三寨尽没，化为冰霜风雪的绝死之地。方源出身地已成废墟。",
        Domain::NanJiang, 0.42, 0.78, "",
        "原著第一卷：白凝冰自爆，青茅山化为冰域绝地", true, LK::Surface, true);

    //
    //  百家寨：南疆凡人出生点（需求 11 身份 2「百家寨孤儿」）。
    //  青茅山既毁，出生地须另择 —— 此寨位于南疆十万大山外缘，
    //  依山建寨，形制同南疆山寨。属工程设定（原著未见此寨名）。
    //
    //
    //  位置依原著校正：
    //
    //    黄龙江「南疆第三江，发源于黄果山，流经玄冥山、龟背山、
    //    青茅山、白骨山、雷磁山等，最后流入到海」。
    //    青茅山一战后，方源与白凝冰扎竹筏顺江而下，
    //    「一路顺江而下，一日千里有余」，第五日「已经很接近白骨山」。
    //
    //    故【青茅山 → 白骨山】约合五日水路，可作标尺。
    //    百家寨在青茅山下游【三日路程】处，即全程的 3/5：
    //      青茅山 (0.420, 0.780) → 白骨山 (0.4625, 0.8225)
    //      沿江方向（以 y 为主）行 3/5 → y ≈ 0.805
    //      黄龙江中心在该处 x ≈ 0.429，寨子贴江而建取 x = 0.432。
    //
    //    此前百家寨在 (0.46, 0.82)，既紧邻青茅山（不合三日路程），
    //    又整体落在白骨山区 (0.440~0.485, 0.800~0.845) 之内 ——
    //    等于把寨子放进了另一座山里。两点皆已修正。
    //
    //  仍属工程设定：原著未见「百家寨」此名，仅借黄龙江水路定位。
    //
    put("baijiazhai", "百家寨",
        "黄龙江畔的山寨，依山傍水，高脚吊楼错落。"
        "自青茅山顺江而下三日路程。族中孤儿于此开窍入道。",
        Domain::NanJiang, 0.432, 0.805, "",
        "工程设定：青茅山已毁，另设南疆出生寨；位置依黄龙江三日水路", false);
    //  商量山：商家城所在。原著「整个商家城就是一座立体的大山」，
    //  此山即商家城依附的山体。
    put("shangliangshan", "商量山", "商家城所在山体，整座城沿山而建、立体铺开",
        Domain::NanJiang, 0.47, 0.72, "", "原著第408集：商家城即一座立体的大山", true);

    // 盗天传承窟：紧邻出生地（青茅山），开局即可触及
    put("nj_daotian_chuancheng", "盗天传承窟",
        "百家寨外的古修窟穴，传闻与盗天魔尊的传承有关",
        Domain::NanJiang, 0.455, 0.795, "nj_daotian_chuancheng",
        "[工程设定] 依「疯魔窟第九层藏盗天真传」推演，设于出生点附近", false);

    // 大地裂缝：宿命蛊摧毁后地脉翻涌所致（B 级推演）
    // —— 地沟下探口：须落在地沟带之上 ——
    //  否则玩家在地表看到沟、走过去却找不到入口，两不相接。
    //  仅北原僵盟地沟、中洲安祖地沟、东海海底地沟为原著可核验之名。
    put("by_jiangmeng_digou", "北原僵盟地沟",
        "僵盟严格把关的地沟入口，资源丰富，荒兽众多",
        Domain::BeiYuan, 0.400, 0.160, "by_jiangmeng_digou",
        "原著 283 节：阴流巨城建造于此，为霸占地沟这条丰富的资源点", true);
    put("cn_anzu_digou", "中洲安祖地沟",
        "驱邪派掌控的地沟，炼蛊大会第八场比试之地",
        Domain::ZhongZhou, 0.515, 0.590, "cn_anzu_digou",
        "原著 189 节：中洲安祖地沟，驱邪派", true);
    put("dh_haidi_digou", "东海海底地沟",
        "海底地沟，盛产黑油，向外溢出如巨蟒触角",
        Domain::DongHai, 0.780, 0.672, "dh_haidi_digou",
        "原著 878 节：方源至海岛附近海中采集地沟黑油", true);
    put("yitianshan", "义天山", "山岳战场，义天山大战核心，属南疆历史创伤点",
        Domain::NanJiang, 0.55, 0.82, "cn_yitian", "地理研究：南疆·义天山", true);
    put("shihuangyuding", "尸皇芋顶", "南疆重要坐标",
        Domain::NanJiang, 0.36, 0.86, "", "地理研究：南疆", true);
    put("yunzhushan", "云竹山", "南疆山岳，云竹丛生",
        Domain::NanJiang, 0.47, 0.70, "", "地理研究：南疆·云竹山", true);
    put("tongyinshan", "铜印山", "南疆重要坐标",
        Domain::NanJiang, 0.58, 0.76, "", "地理研究：南疆·铜印山", true);
    put("wujieshanmai", "五界山脉", "南疆十万大山中的界山",
        Domain::NanJiang, 0.62, 0.90, "", "地理研究：南疆·五界山脉", true);
    put("huxianfudi", "狐仙福地", "南疆关联福地，早期剧情核心",
        Domain::NanJiang, 0.46, 0.74, "nj_huxian_fudi", "地理研究：狐仙福地", true);
    put("huanglongjiang", "黄龙江", "贯穿南疆山脉的三江之一，少数贯通性水路",
        Domain::NanJiang, 0.44, 0.80, "", "地理研究：南疆·黄龙江", true);
    put("chilongjiang", "赤龙江", "贯穿南疆山脉的三江之一",
        Domain::NanJiang, 0.52, 0.86, "", "地理研究：南疆·赤龙江", true);
    put("bilongjiang", "碧龙江", "贯穿南疆山脉的三江之一",
        Domain::NanJiang, 0.40, 0.90, "", "地理研究：南疆·碧龙江", true);
    put("baixiangdongtian", "白相洞天", "位于南疆高空，说明南疆上空并非只有山峰，"
        "也有通向两天与仙窍的垂直通道",
        //
        //  原 fx/fy = 0.50/0.70：该点落在中洲，而白相洞天明载「南疆高空」。
        //  域界改为不规则后，域中心附近也可能落到邻域 ——
        //  按域中心布点不再可靠。取实测南疆范围内的点（南疆 y 0.59~0.99）。
        //
        Domain::NanJiang, 0.44, 0.79, "nj_baixiang", "地理研究：南疆·白相洞天", true, LK::TwoHeavens);

    // —— 西漠（A 级）——
    put("zenduqiu", "怎渡丘", "数十万里规模的移动沙丘，固定曲线上没有绿洲、山石与猛兽，"
        "只有黄沙，连八转蛊仙也难以正面阻挡",
        Domain::XiMo, 0.14, 0.50, "", "地理研究：西漠·怎渡丘", true);
    put("wankuanggebi", "万矿戈壁", "体现西漠矿物价值的戈壁",
        Domain::XiMo, 0.22, 0.36, "", "地理研究：西漠·万矿戈壁", true);
    put("tianlu", "天露绿洲", "西漠绿洲之一，人口与资源的硬节点",
        Domain::XiMo, 0.10, 0.62, "", "地理研究：西漠·绿洲", true);
    put("baoyue", "宝月绿洲", "西漠绿洲之一，家族控制权争夺点",
        Domain::XiMo, 0.16, 0.44, "", "地理研究：西漠·绿洲", true);
    put("gaosong", "高松绿洲", "西漠绿洲之一，商路节点",
        Domain::XiMo, 0.24, 0.58, "", "地理研究：西漠·绿洲", true);
    put("fangjia", "房家", "西漠十四家族之一，偷道真传所在",
        Domain::XiMo, 0.26, 0.66, "", "地理研究：西漠·十四家族", true);
    put("yijia", "羿家", "带有羽民血统的西漠家族",
        Domain::XiMo, 0.12, 0.34, "", "地理研究：西漠·羿家", true);

    // —— 东海（A 级）——
    put("longyuhaiyu", "龙鱼海域", "东海以海域而非行政区划分",
        Domain::DongHai, 0.77, 0.42, "", "地理研究：东海·龙鱼海域", true);
    put("luanliuhaiyu", "乱流海域", "东海海域之一，海况复杂",
        Domain::DongHai, 0.86, 0.56, "", "地理研究：东海·乱流海域", true);
    put("sheyuhaiyu", "射鱼海域", "东海海域之一",
        Domain::DongHai, 0.80, 0.48, "", "地理研究：东海·射鱼海域", true);
    put("guangbohaiyu", "光波海域", "东海海域之一",
        Domain::DongHai, 0.90, 0.38, "", "地理研究：东海·光波海域", true);
    put("longjingleitu", "龙鲸乐土", "苍蓝龙鲸关联洞天，跨域交易网络节点",
        Domain::DongHai, 0.80, 0.34, "dh_longjing_letu", "地理研究：东海·龙鲸乐土", true);
    put("jiaorewangting", "鲛人王庭", "五域唯一异人超级势力，后为天地一家大爱盟重要组成",
        Domain::DongHai, 0.72, 0.62, "", "地理研究：东海·鲛人王庭", true);
    //  0.74 处落在中洲一侧（极坐标域界在此处向内凹），
    //  而青岳家据东海海域，故东移至 0.83 确保其落在东海内。
    put("qingyuejia", "青岳家", "东海八大家之一，据海域分布",
        Domain::DongHai, 0.83, 0.30, "", "地理研究：东海·八大家", true);

    // —— 仙窍内部 / 域外规则空间：【不】落在地表图上 ——
    //
    //  仙窍内部 / 域外规则空间 —— 本就不该有地表坐标。
    //
    //  此前一律填 (0.0, 0.0) 作占位，结果地图扩至 2048×1536 后，
    //  这六条被算作「落在西漠 (0,0) 的地标」—— 而 (0,0) 恰好在西漠。
    //  总表反复警告「荡魂山、落魄谷在琅琊福地内，绝不能标成五域地表山川」，
    //  这类占位正是那条警告最易混入的缝隙：不是标错域，
    //  而是压根不该有坐标。
    //
    //  故改为 -1（无地表坐标），地表图与域校验皆不涉及它们。
    //
    constexpr double kNoPos = -1.0;
    put("danghunshan", "荡魂山", "魂道奇山，原在南疆体系，后被收于琅琊福地 —— 属仙窍内坐标",
        Domain::NanJiang, kNoPos, kNoPos, "", "地理研究：著名地点清单", true, LK::InsideCave);
    put("luopogu", "落魄谷", "琅琊福地内部的特殊地形/资源，随福地迁移",
        Domain::None, kNoPos, kNoPos, "", "地理研究：著名地点清单", true, LK::InsideCave);
    put("niliuhe", "逆流河", "至尊仙窍内「小东海」区域的宙道/规则型河流，方源可控",
        Domain::None, kNoPos, kNoPos, "", "地理研究：著名地点清单", true, LK::InsideCave);
    put("guangyinchanghe", "光阴长河", "域外/宙道至高空间，不等同五域河流，红莲线关键，"
        "不宜误标在某域地表",
        Domain::None, kNoPos, kNoPos, "", "地理研究：著名地点清单", true, LK::OuterRule);
    put("zhizunxianqiao", "至尊仙窍", "方源的仙窍，内部已有小东海等五域式区域；"
        "支线「方源将定仙游借给你」的目的地",
        Domain::ZhongZhou, kNoPos, kNoPos, "cn_zunzhe_xiantiao", "地理研究 + 需求构造", false, LK::InsideCave);
    put("baohuangtian", "宝黄天", "黄天碎片＋洞天形成的交易市场，不属于单一五域地表；"
        "因碎片而免灾，屹立至今",
        Domain::None, kNoPos, kNoPos, "cn_baohuangtian", "地理研究：宝黄天", true, LK::OuterRule);

    // ------------------------------------------------------------------
    //  ③ 原著固定地形：这些在原文有明确定位，必须固定生成
    //
    //  依据「蛊真人两天五域地理研究」：
    //    中洲：落天河、罐河等大川，深不见底的地渊，高山云海
    //    北原：苍莽草地、冰原、周期性超级大风雪；王庭福地；疯魔窟九层
    //    南疆：连绵山脉与十万大山；黄龙、赤龙、碧龙三江贯穿山脉；瘴气
    //    西漠：戈壁沙漠、万矿戈壁；数十万里规模的移动沙丘「怎渡丘」；
    //          天露、宝月、高松等绿洲
    //    东海：龙鱼、乱流、射鱼、光波四大海域；星罗海岛；海底潜流
    // ------------------------------------------------------------------
    using CS = CanonShape;
    auto zone = [&](const char* id, const char* name, Domain d, CS shape,
                    double a0, double a1, double a2, double a3, double a4,
                    Terrain tr, const char* src, bool canon = true) {
        CanonTerrainZone z;
        z.id = id; z.name = name; z.domain = d; z.shape = shape;
        if (shape == CS::Rect) { z.x0 = a0; z.y0 = a1; z.x1 = a2; z.y1 = a3; }
        else { z.ax = a0; z.ay = a1; z.bx = a2; z.by = a3; z.halfWidth = a4; }
        z.terrain = tr; z.source = src; z.canon = canon;
        map.addCanonZone(z);
    };

    // ———— 中洲：大川与深壑（研究：落天河、罐河、地渊，A/B 级）————
    //
    //  落天河：总表载「从万丈高空垂落，斜穿整个中洲，东流出中洲入东海」，
    //  并形成「横贯中洲大陆的第一长河」。此前只画到中洲中部，
    //  未东出中洲 —— 与总表所述不符，故延伸至东海一侧。
    //
    zone("luotianhe_z", "落天河", Domain::ZhongZhou, CS::Band,
         0.403, 0.363, 0.700, 0.660, 0.014, Terrain::Water,
         "地理研究：中洲·落天河（大川）");
    zone("guanhe_z", "罐河", Domain::ZhongZhou, CS::Band,
         0.520, 0.380, 0.610, 0.600, 0.014, Terrain::Water,
         "地理研究：中洲·罐河（大川）");
    zone("diyuan_z", "地渊", Domain::ZhongZhou, CS::Rect,
         0.545, 0.520, 0.600, 0.575, 0, Terrain::Abyss,
         "地理研究：中洲·地渊（深不见底的深渊）");
    zone("zhongzhou_shan", "中洲高山云海", Domain::ZhongZhou, CS::Rect,
         0.445, 0.595, 0.515, 0.645, 0, Terrain::Mountain,
         "地理研究：中洲高山、云海、三万丈以上高空悬山福地");

    // ———— 北原：草原为底，北部冰原，疯魔窟为九层凶地 ————
    //  原 y 下缘 0.220 已探入中洲北缘，故整体上移 0.045
    zone("beiyuan_caoyuan", "苍莽草地", Domain::BeiYuan, CS::Rect,
         0.300, 0.015, 0.700, 0.175, 0, Terrain::Grassland,
         "地理研究：北原核心地貌「苍莽草地、大风」");
    zone("beiyuan_bingyuan", "冰原与风雪带", Domain::BeiYuan, CS::Rect,
         0.300, 0.000, 0.700, 0.070, 0, Terrain::IceField,
         "地理研究：北原冰原及周期性超级大风雪");
    zone("fengmoku_z", "疯魔窟（北原十大凶地之一）", Domain::BeiYuan, CS::Rect,
         0.340, 0.157, 0.380, 0.202, 0, Terrain::Rainforest,
         "地理研究：疯魔窟第一层为雨林式外部世界，九层嵌套");

    // ———— 南疆：十万大山与三江————
    zone("shiwandashan", "十万大山", Domain::NanJiang, CS::Rect,
         0.360, 0.720, 0.640, 0.840, 0, Terrain::Mountain,
         "地理研究：南疆由连绵山脉和十万大山组成");
    zone("huanglongjiang_z", "黄龙江", Domain::NanJiang, CS::Band,
         0.415, 0.700, 0.450, 0.960, 0.007, Terrain::Water,
         "地理研究：黄龙、赤龙、碧龙三江贯穿山脉，少数贯通性水路");
    zone("chilongjiang_z", "赤龙江", Domain::NanJiang, CS::Band,
         0.515, 0.720, 0.529, 0.980, 0.007, Terrain::Water,
         "地理研究：南疆三江之一");
    zone("bilongjiang_z", "碧龙江", Domain::NanJiang, CS::Band,
         0.380, 0.760, 0.405, 0.980, 0.007, Terrain::Water,
         "地理研究：南疆三江之一");
    zone("nanjiang_zhangqi", "瘴气山谷", Domain::NanJiang, CS::Rect,
         0.560, 0.820, 0.640, 0.900, 0, Terrain::ToxicForest,
         "地理研究：南疆湿润多雾、瘴气与兽潮");

    // ———— 西漠：沙漠戈壁、万矿戈壁、怎渡丘、三大绿洲————
    zone("ximo_shamo", "戈壁沙漠", Domain::XiMo, CS::Rect,
         0.020, 0.380, 0.180, 0.620, 0, Terrain::Desert,
         "地理研究：西漠以戈壁、沙漠、绿洲为基本单元");
    zone("wankuanggebi_z", "万矿戈壁", Domain::XiMo, CS::Rect,
         0.155, 0.280, 0.245, 0.360, 0, Terrain::Mountain,
         "地理研究：万矿戈壁体现西漠矿物价值");
    zone("zenduqiu_z", "怎渡丘（移动沙丘）", Domain::XiMo, CS::Band,
         0.080, 0.470, 0.200, 0.520, 0.016, Terrain::SandDune,
         "地理研究：数十万里规模迁移的沙丘，固定曲线上没有绿洲山石猛兽，只有黄沙");
    zone("tianlu_z", "天露绿洲", Domain::XiMo, CS::Rect,
         0.085, 0.600, 0.125, 0.645, 0, Terrain::Oasis,
         "地理研究：天露、宝月、高松等绿洲是人口与资源的硬节点");
    zone("baoyue_z", "宝月绿洲", Domain::XiMo, CS::Rect,
         0.120, 0.417, 0.160, 0.462, 0, Terrain::Oasis,
         "地理研究：绿洲为家族控制权争夺点");
    zone("gaosong_z", "高松绿洲", Domain::XiMo, CS::Rect,
         0.220, 0.560, 0.262, 0.605, 0, Terrain::Oasis,
         "地理研究：绿洲—商路—遗迹为轴心");

    // ———— 地沟：原著实有，五域皆有 ————
    //
    //  【已更正】此前只在中洲、南疆设地沟，且归因为「地脉翻涌」，均为错。
    //  原著第 283 节「终入地沟」明写：
    //    「并不是北原才有地沟，事实上，五域都存在着地沟。」
    //    「大地裂开沟壑，有的地沟绵延千万里，有的深达数百万丈，深不见底。」
    //  故五域各设地沟。地表上是【一条裂开的沟】，而非孤零零一个点 ——
    //  否则玩家在地表根本看不到「沟」的存在。
    //
    //  另注：地沟为「十地」之一，可承担地脉节点（乐土真传）。
    zone("digou_beiyuan", "北原僵盟地沟", Domain::BeiYuan, CS::Band,
         0.330, 0.115, 0.470, 0.205, 0.014, Terrain::EarthRift,
         "原著：北原僵盟地沟，阴流巨城为霸占此资源点而建", true);
    zone("digou_zhongzhou", "中洲安祖地沟", Domain::ZhongZhou, CS::Band,
         0.430, 0.500, 0.600, 0.680, 0.013, Terrain::EarthRift,
         "原著：中洲安祖地沟，驱邪派掌控", true);
    // 东海海底地沟：原著为【某海岛附近】的海底地沟（方源赴海岛采黑油），
    // 并非横贯东海的长带。此前画得太长，斜穿龙鱼／射鱼／乱流三片海域，
    // 而 canonZoneAt 取面积最小的命中区，地沟带比海域小，
    // 于是把乱流海域整片吞掉 —— 与原著定点冲突。
    // 现缩为东南一隅的短带，避开四大海域。
    zone("digou_donghai", "东海海底地沟", Domain::DongHai, CS::Band,
         0.700, 0.655, 0.860, 0.690, 0.011, Terrain::EarthRift,
         "原著 878 节：东海海底地沟，盛产黑油（位于海岛附近）", true);
    zone("digou_nanjiang", "南疆地沟", Domain::NanJiang, CS::Band,
         0.470, 0.860, 0.560, 0.960, 0.011, Terrain::EarthRift,
         "原著：五域皆有地沟（南疆具体位置原著未载，此处为工程落点）", false);
    //  东端原至 0.250，已探入中洲西缘，故收至 0.170
    zone("digou_ximo", "西漠地沟", Domain::XiMo, CS::Band,
         0.060, 0.340, 0.170, 0.400, 0.011, Terrain::EarthRift,
         "原著：五域皆有地沟（西漠具体位置原著未载，此处为工程落点）", false);

    // ———— 东海：四大海域、群岛、海底潜流 ————
    zone("longyu_haiyu", "龙鱼海域", Domain::DongHai, CS::Rect,
         0.775, 0.365, 0.875, 0.475, 0, Terrain::Sea,
         "地理研究：东海以龙鱼、乱流、射鱼、光波等海域划分");
    zone("luanliu_haiyu", "乱流海域", Domain::DongHai, CS::Rect,
         0.840, 0.520, 0.940, 0.610, 0, Terrain::Sea,
         "地理研究：东海乱流海域");
    zone("sheyu_haiyu", "射鱼海域", Domain::DongHai, CS::Rect,
         0.780, 0.450, 0.880, 0.545, 0, Terrain::Sea,
         "地理研究：东海射鱼海域");
    zone("guangbo_haiyu", "光波海域", Domain::DongHai, CS::Rect,
         0.875, 0.330, 0.980, 0.425, 0, Terrain::Sea,
         "地理研究：东海光波海域");
    zone("haidi_qianliu", "海底潜流航路", Domain::DongHai, CS::Band,
         0.690, 0.400, 0.960, 0.560, 0.010, Terrain::Undercurrent,
         "地理研究：海底潜流被商人直接用作天然航路，可跨数万至数十万里");

    //
    //  青茅山冰域：白凝冰自爆所致的绝死冰域（原地标 (0.42, 0.78)）。
    //  原先此处是郁郁葱葱的山地，第一卷后化为冰霜风雪之地，
    //  故地形为冰原而非山林 —— 不照旧样貌生成。
    //
    zone("qingmao_icefield", "青茅山冰域绝地", Domain::NanJiang, CS::Rect,
         0.385, 0.745, 0.455, 0.815, 0,
         Terrain::IceField, "原著第一卷：白凝冰自爆，青茅山化为冰域绝地");
    //  冰域是「事件改变地貌」，须覆写黄龙江等原本的自然地物
    {
        std::vector<CanonTerrainZone>& zs =
            const_cast<std::vector<CanonTerrainZone>&>(map.canonZones());
        for (auto& z : zs)
            if (z.id == "qingmao_icefield") z.overlay = true;
    }

    //
    //  ③ 原著地点总表（206 条）—— 地表条目登记为地标
    //
    //  总表口径：坐标分三层，五域地表／两天／洞天内。
    //  只有 Surface 条目落在地表图上；两天与洞天内条目
    //  仅作数据登记（gr::canon::allPlaces），不画在地表 ——
    //  把荡魂山、逆流河画到五域地表，正是总表反复警告的错误。
    //
    {
        std::size_t added = 0;
        for (const auto& p : gr::canon::allPlaces()) {
            if (p.kind != gr::canon::CanonPlace::Kind::Surface) continue;
            if (p.fx < 0.0 || p.fy < 0.0) continue;
            //
            //  注册前先校验坐标是否真的落在所属域内。
            //
            //  地图扩至 2048×1536 后实测有 7 处「域错位」：
            //    白相洞天      —— 落到了别的域
            //    荡魂山、落魄谷、逆流河、光阴长河、至尊仙窍、宝黄天
            //                   —— 坐标是 (0,0)，即生成器给的占位默认值
            //
            //  后六个尤其危险：总表反复警告「荡魂山、落魄谷在琅琊福地内，
            //  绝不能标成五域地表山川」。它们本就不该有地表坐标，
            //  却因 fx/fy 为 0（而非 -1）而通过了上面两道过滤，
            //  被当成 (0,0) 处的地表地标登记 —— 正是总表警告的那类错误，
            //  只是换了个形式混进来。
            //
            //  故在此以域为判据再拦一道：坐标不在本域者一律不注册为地标，
            //  只作数据条目（仍可在见闻录里查到，不画进地图）。
            //
            {
                const int px = static_cast<int>(W * p.fx);
                const int py = static_cast<int>(H * p.fy);
                if (!map.inBounds(px, py)) continue;
                if (map.domainAt(px, py) != p.domain) continue;
            }
            //  已由上文定点登记的（如青茅山、百家寨）不重复登记
            bool dup = false;
            for (const auto& lm : map.landmarks())
                if (lm.name == p.name) { dup = true; break; }
            if (dup) continue;

            Landmark lm;
            lm.id = "cp_" + std::to_string(added);
            lm.name = p.name;
            lm.desc = p.type + "（" + p.posText + "）";
            lm.domain = p.domain;
            lm.x = static_cast<int>(W * p.fx);
            lm.y = static_cast<int>(H * p.fy);
            lm.source = "地点总表：" + p.statusDesc;
            lm.canon = (p.evidence == gr::canon::CanonPlace::Evidence::A);
            lm.evidence = (p.evidence == gr::canon::CanonPlace::Evidence::A)
                            ? Landmark::Evidence::A
                            : (p.evidence == gr::canon::CanonPlace::Evidence::B)
                                ? Landmark::Evidence::B
                                : Landmark::Evidence::C;
            lm.status = static_cast<Landmark::Status>(p.status);
            lm.scaleDesc   = p.scaleDesc;
            lm.statusDesc  = p.statusDesc;
            lm.positionCanon = p.positionCanon;
            map.addLandmark(lm);
            ++added;
        }
    }

    //
    //  ④ 依《两天五域地点总表》补充的地形区
    //
    //  总表 206 条中，地表条目凡有明确地形的，在此登记为固定地形区。
    //  原文未给方位者标 canon=false —— 照总表口径「不估算、不换算」，
    //  落点是工程布点，不是原著坐标。
    //
    // —— 东海：总表载九大海域（此前只登记四处）——
    zone("lvbo_haiyu",     "绿波海域", Domain::DongHai, CS::Rect,
         0.800, 0.260, 0.880, 0.350, 0, Terrain::Sea,
         "地点总表：东海·绿波海域", true);
    zone("shahai_haiyu",   "鲨海海域", Domain::DongHai, CS::Rect,
         0.820, 0.620, 0.910, 0.720, 0, Terrain::Sea,
         "地点总表：东海·鲨海海域（鲨魔掌控）", true);
    zone("jinxiu_haiyu",   "锦绣海域", Domain::DongHai, CS::Rect,
         0.910, 0.470, 0.980, 0.580, 0, Terrain::Sea,
         "地点总表：东海·锦绣海域", true);
    zone("dianbo_haiyu",   "颠簸海域", Domain::DongHai, CS::Rect,
         0.740, 0.560, 0.850, 0.660, 0, Terrain::Sea,
         "地点总表：东海·颠簸海域", true);
    zone("shiqing_haiyu", "诗情海域", Domain::DongHai, CS::Rect,
         0.860, 0.390, 0.960, 0.490, 0, Terrain::Sea,
         "地点总表：东海·诗情海域（宋亦诗私人海域）", true);
    zone("jiaoren_haiyu",  "鲛人海域", Domain::DongHai, CS::Rect,
         0.700, 0.640, 0.800, 0.730, 0, Terrain::Sea,
         "地点总表：东海·鲛人海域（海底，鲛人族集中分布）", true);

    // —— 西漠：总表载多片沙漠、戈壁、绿洲与火山天坑 ——
    zone("qinggui_shamo",  "青鬼沙漠", Domain::XiMo, CS::Rect,
         0.060, 0.370, 0.150, 0.470, 0, Terrain::Desert,
         "地点总表：西漠·青鬼沙漠", true);
    zone("zhendang_shamo", "震荡沙漠", Domain::XiMo, CS::Rect,
         0.050, 0.540, 0.140, 0.630, 0, Terrain::Desert,
         "地点总表：西漠·震荡沙漠", true);
    zone("fengsun_shamo",  "风隼沙漠", Domain::XiMo, CS::Rect,
         0.130, 0.550, 0.220, 0.620, 0, Terrain::Desert,
         "地点总表：西漠·风隼沙漠（高松绿洲风隼族群活动区）", true);
    zone("liaoying_gebi",  "燎萤戈壁", Domain::XiMo, CS::Rect,
         0.080, 0.310, 0.170, 0.380, 0, Terrain::Gobi,
         "地点总表：西漠·燎萤戈壁（被方源屠戮）", true);
    zone("guanxiang_lvzhou","观想绿洲", Domain::XiMo, CS::Rect,
         0.140, 0.500, 0.190, 0.560, 0, Terrain::Oasis,
         "地点总表：西漠·观想绿洲（万家拟割让萧家）", true);
    zone("xiangfeng_flyisland","香风飞岛", Domain::XiMo, CS::Rect,
         0.110, 0.440, 0.160, 0.490, 0, Terrain::FlyingIsland,
         "地点总表：西漠·香风飞岛（万家资源点）", true);
    zone("xuanhuang_dichi", "玄黄地池", Domain::XiMo, CS::Rect,
         0.150, 0.600, 0.210, 0.660, 0, Terrain::Lake,
         "地点总表：西漠·玄黄地池（万家资源点）", true);
    zone("longyin_huoshan", "龙吟火山", Domain::XiMo, CS::Rect,
         0.130, 0.660, 0.200, 0.720, 0, Terrain::Volcano,
         "地点总表：西漠·龙吟火山（被房家攻取，岩浆被抽走）", true);
    zone("shangqing_caoyuan","上清草原", Domain::XiMo, CS::Rect,
         0.160, 0.700, 0.230, 0.760, 0, Terrain::Grassland,
         "地点总表：西漠·上清草原（西漠罕见草原，被房家攻陷）", true);
    zone("gujia_shan",     "骨架山", Domain::XiMo, CS::Rect,
         0.090, 0.260, 0.170, 0.340, 0, Terrain::Mountain,
         "地点总表：西漠·骨架山（习家领地边线，被房家攻取后消失）", true);

    // —— 南疆：三江沿岸山系（总表给出黄龙江流经序列）——
    //    黄果山 → 玄冥山 → 龟背山 → 青茅山 → 白骨山 → 雷磁山
    zone("huangguo_shan",  "黄果山", Domain::NanJiang, CS::Rect,
         0.310, 0.700, 0.360, 0.750, 0, Terrain::Mountain,
         "地点总表：南疆·黄果山（黄龙江发源地）", true);
    zone("xuanming_shan",  "玄冥山", Domain::NanJiang, CS::Rect,
         0.350, 0.740, 0.395, 0.790, 0, Terrain::Mountain,
         "地点总表：南疆·玄冥山（黄龙江上游，黄果山之后）", true);
    zone("guibei_shan",    "龟背山", Domain::NanJiang, CS::Rect,
         0.350, 0.800, 0.390, 0.840, 0, Terrain::Mountain,
         "地点总表：南疆·龟背山（黄龙江自玄冥山向东南流后经过）", true);
    zone("baigu_shan",     "白骨山", Domain::NanJiang, CS::Rect,
         0.440, 0.800, 0.485, 0.845, 0, Terrain::Mountain,
         "地点总表：南疆·白骨山（黄龙江流经青茅山之后）", true);
    zone("leici_shan",     "雷磁山", Domain::NanJiang, CS::Rect,
         0.465, 0.830, 0.510, 0.875, 0, Terrain::Mountain,
         "地点总表：南疆·雷磁山（黄龙江流经白骨山后）", true);
    zone("baizu_shan",     "百足山", Domain::NanJiang, CS::Rect,
         0.320, 0.830, 0.360, 0.870, 0, Terrain::Mountain,
         "地点总表：南疆·百足山（黄龙江流经山系之一）", true);
    zone("jiangxin_xuanwo","江心漩涡", Domain::NanJiang, CS::Rect,
         0.530, 0.825, 0.575, 0.870, 0, Terrain::Water,
         "地点总表：南疆·江心漩涡（赤龙江、黄龙江交汇处中心）", true);
    zone("shihuang_yuding","尸皇芋顶", Domain::NanJiang, CS::Rect,
         0.550, 0.800, 0.595, 0.845, 0, Terrain::Mountain,
         "地点总表：南疆·尸皇芋顶（江心漩涡东北岸，尸山高达数百丈）", true);
    zone("duwen_pubu",     "毒瘟瀑布", Domain::NanJiang, CS::Rect,
         0.390, 0.920, 0.435, 0.960, 0, Terrain::Waterfall,
         "地点总表：南疆·毒瘟瀑布（羊家与武家疆域交界，高十八丈）", true);
    zone("yitian_shan",    "义天山", Domain::NanJiang, CS::Rect,
         0.525, 0.785, 0.570, 0.830, 0, Terrain::Mountain,
         "地点总表：南疆·义天山（两度正魔大战战场）", true);
    zone("wujie_shanmai",  "五界山脉", Domain::NanJiang, CS::Rect,
         0.595, 0.760, 0.650, 0.820, 0, Terrain::Mountain,
         "地点总表：南疆·五界山脉（陶铸仿五域界壁所造，非自然山脉）", true);

    // —— 中洲：总表载资源点 ——
    zone("linghu_quan",    "灵浒泉", Domain::ZhongZhou, CS::Rect,
         0.600, 0.500, 0.640, 0.540, 0, Terrain::Spring,
         "地点总表：中洲·灵浒泉（被方源搬入至尊仙窍）", true);
    zone("xuanyu_sheku",   "玄玉蛇窟", Domain::ZhongZhou, CS::Rect,
         0.560, 0.435, 0.610, 0.485, 0, Terrain::Cave,
         "地点总表：中洲·玄玉蛇窟（洞窟万千，宇道嵌套空间）", true);
    zone("canglong_ku",    "藏龙窟", Domain::ZhongZhou, CS::Rect,
         0.515, 0.460, 0.560, 0.510, 0, Terrain::Cave,
         "地点总表：中洲·藏龙窟（曾禁锢太古荒兽帝藏生）", true);
    zone("diqi_shilin",    "地气石林", Domain::ZhongZhou, CS::Rect,
         0.465, 0.560, 0.510, 0.605, 0, Terrain::StoneForest,
         "地点总表：中洲·地气石林", true);
    zone("baijie_lindi",   "百节林地", Domain::ZhongZhou, CS::Rect,
         0.500, 0.610, 0.550, 0.655, 0, Terrain::Forest,
         "地点总表：中洲·百节林地", true);
    zone("linguang_he",    "磷光河", Domain::ZhongZhou, CS::Band,
         0.440, 0.680, 0.520, 0.700, 0.010, Terrain::Water,
         "地点总表：中洲·磷光河", true);

    // —— 北原：总表载大雪山、太丘、龙象原、月牙湖 ——
    zone("daxue_shan",     "大雪山", Domain::BeiYuan, CS::Rect,
         0.620, 0.020, 0.720, 0.090, 0, Terrain::SnowPeak,
         "地点总表：北原·大雪山（北原第一魔道势力）", true);
    zone("taiqiu",         "太丘", Domain::BeiYuan, CS::Rect,
         0.330, 0.080, 0.395, 0.140, 0, Terrain::Hill,
         "地点总表：北原·太丘（十大凶地之一，关家东南、刘家西北）", true);
    zone("longxiang_yuan", "龙象原", Domain::BeiYuan, CS::Rect,
         0.290, 0.140, 0.370, 0.190, 0, Terrain::Grassland,
         "地点总表：北原·龙象原", true);
    zone("yueya_hu",       "月牙湖", Domain::BeiYuan, CS::Rect,
         0.255, 0.100, 0.345, 0.165, 0, Terrain::Lake,
         "地点总表：北原·月牙湖（湖长约十五千里，平均宽度五千里）", true);

    // 关键：至此所有配置（分区 / 原著地形区 / 地标）才登记完毕。
    // 其间 addLandmark 已触发过部分块的构建，而那时原著地形区可能尚未登记，
    // 那些块就被固化成了「没有原著地形」的样子。故整体失效一次，
    // 让全部块按完整配置重建 —— 否则会出现同一条河一段是水、一段是草原。
    map.invalidateChunks();

    // 地形改为按需现算，块在首次访问时才依完整配置构建
    return { true, "地图骨架就绪：" + std::to_string(W) + "×" + std::to_string(H) +
                   "（" + std::to_string(map.chunkCols() * map.chunkRows()) +
                   " 块，地形按需现算，探索状态落外存）" };
}


//  naturalDomainAt 须定义在 polarDomainAt 之后（后者在上方匿名 namespace 内），
//  故放在文件末尾。
Domain TileMap::naturalDomainAt(int x, int y) const {
    if (!inBounds(x, y)) return Domain::None;
    return polarDomainAt(x, y, w_, h_, seed_).dom;
}

} // namespace gr
