# Android 端

将《蛊真人》搬到 Android 平台。核心逻辑（世界、规则、蛊虫、界面）**一行未改**，
只在最外层接了一个 Android 后端。

## 架构

```
┌─────────────────────────────────────────────┐
│  Java: GzrActivity（继承 NativeActivity）     │
│    只做一件事 —— 中文输入法（透明 EditText）   │
└──────────────────┬──────────────────────────┘
                   │ JNI: nativeCommitText
┌──────────────────▼──────────────────────────┐
│  C++: android_main.cpp（主循环）              │
│    ImGui::NewFrame → buildFrame → Render     │
│      → soft::renderDrawData（软件光栅化）      │
│      → backend.present（letterbox 贴屏）      │
└──────────────────┬──────────────────────────┘
                   │
┌──────────────────▼──────────────────────────┐
│  核心层：GameSession / ImGuiApp / SoftRenderer │
│    纯 C++，不认识任何平台 → 与桌面版共享源码    │
└─────────────────────────────────────────────┘
```

## 三个关键决策

### 一、虚拟分辨率固定 1440×900，letterbox 贴屏

界面布局是按 1440×900 逐像素调过的（左面板 320px、下图例 136px、
炼蛊台只压主区……）。若让手机按物理分辨率重新走一遍布局，
等于把布局全部重做，且两边必然对不齐。

所以手机上**仍然渲染 1440×900 的画面**，再等比缩放居中贴到物理屏，
留黑边。布局代码一行不改，桌面与手机永远一致。

例：横屏 2400×1080
```
scale = min(2400/1440, 1080/900) = min(1.667, 1.200) = 1.200
画面 1728×1080 居中，左右各留 336 黑边
```

触摸坐标需**反变换**回虚拟坐标，否则手指位置与控件对不上。
点黑边不触发点击——否则点画面外会命中画面内的控件。

这部分是纯数学，抽在 `src/ui/AndroidViewport.{hpp,cpp}`，
**不含任何 NDK 头文件**，故能在 Linux 上编译并单测（见 `tests/test_android.cpp`）。

### 二、软件光栅化，不引入 OpenGL

复用已有的 `soft::Bitmap` 光栅化器。理由：

- 核心层本来就是软件渲染，接 OpenGL 要写一套纹理上传路径，收益为零
- 界面是静态为主，帧率要求不高
- 不引 GPU 依赖，兼容性问题少

`ANativeWindow_lock` 拿缓冲 → 缩放贴入 → `unlockAndPost`。
缓冲格式按 RGBA8888 申请，设备不支持时退回 RGB565 路径（两条都实现了）。

### 三、中文输入必须走 Java 层

NativeActivity 的原生 IME **只支持 ASCII，打不出中文**——
而开局取名、取假名都要打中文。

方案：Java 侧放一个近乎不可见的 `EditText`（1×1、全透明）承接输入法，
提交文本后通过 JNI 回调给 C++，再喂给 ImGui。

为什么 EditText 要 1×1 透明而不是 `GONE`：`GONE` 的 View 无法唤起输入法。

## 工程结构（解压后即工程根）

```
Android_guzhenren/            ← 工程根，直接用工具/AS 打开这一层
├── app/
│   ├── app_config.json       ← 模块配置（应用名/包名/版本/NDK）
│   ├── build.gradle
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── assets/fonts/     ← 自带中文字体
│       ├── cpp/              ← native 入口与后端
│       ├── java/com/gzr/game/GzrActivity.java
│       └── res/
├── build.gradle              ← 根构建脚本（声明 AGP 插件，必需）
├── settings.gradle
├── gradle.properties
├── gradle/wrapper/
├── build.sh
└── README.md
```

注意：zip **不含**外层的 `android/` 目录 —— 解压后 `app/` 直接位于工程根，
否则工具会报「无效的 Android 工程目录」。

## 文件

| 文件 | 说明 |
|---|---|
| `src/main/cpp/android_main.cpp` | 入口与主循环 |
| `src/main/cpp/AndroidBackend.{hpp,cpp}` | 窗口 / 输入 / 资源 / 呈现 |
| `src/main/cpp/jni_bridge.cpp` | 中文输入 JNI 回调 |
| `src/main/cpp/CMakeLists.txt` | 编译核心源码 + imgui |
| `src/main/java/com/gzr/game/GzrActivity.java` | 宿主 Activity |
| `src/main/assets/fonts/*.ttf` | 自带中文字体（系统字体不含完整 CJK） |
| `build.sh` | 一键构建 |

## 构建

**沙盒内无法完成真实构建** —— 网络仅放行白名单，下载不到 gradle / SDK / NDK。
这里交付的是**可在 Android Studio 直接打开**的完整工程。

在有 SDK/NDK 的机器上：

```bash
export ANDROID_SDK_ROOT=$HOME/Android/Sdk
export ANDROID_NDK_HOME=$ANDROID_SDK_ROOT/ndk/25.2.9519653
bash android/build.sh debug      # 或 release
```

或直接用 Android Studio `Open` 选中 `android/` 目录。

## 故障排查

### 启动时 `Unable to find native library guzhenren`

**含义**：APK 的 `lib/<abi>/` 里没有 `libguzhenren.so`。

先定性：
```bash
unzip -l your.apk | grep libguzhenren
```
无输出即确认。

#### 解法：预编译 .so + 打包（无需构建环境支持 CMake）

工程已支持两条来源，`app/build.gradle` 会自动判断：

| 情况 | 行为 |
|---|---|
| `app/src/main/jniLibs/<abi>/libguzhenren.so` 存在 | 直接打包，**不跑 CMake** |
| 不存在 | 走 CMake 构建 |

所以只要在任何有 NDK 的机器上产出一次 .so，放进 `jniLibs/`，
之后用**任何**打包工具（含不执行 CMake 的手机端 IDE）都能打出可用的 APK。

```bash
bash android/build.sh debug      # 会自动把 .so 回填进 jniLibs/
```

目录结构：
```
app/src/main/jniLibs/
└── arm64-v8a/libguzhenren.so     ← 绝大多数现代安卓机需要这个
```

#### 为什么要有这个设计

多数手机端编译工具只做 Java 编译与打包，不执行 `externalNativeBuild`，
于是 C++ 部分被静默跳过 —— APK 编得出来，一启动就崩。
预编译 .so 放进 jniLibs 即可绕开这一限制。

### 启动时 `UnsatisfiedLinkError: library "libguzhenren.so" not found`

即 APK 里**没有** native 库。按以下顺序查：

1. **APK 里到底有没有 .so**
   ```bash
   unzip -l app-debug.apk | grep libguzhenren
   ```
   若为空，说明 CMake 压根没执行（或执行失败），往下查。

2. **构建日志里搜 CMake**
   多数轻量/手机端编译工具**不支持 `externalNativeBuild`**，
   会跳过 native 构建、只打 Java 部分 —— 这正是本工程最常见的结果。
   此类工具无法编译 NDK 工程，需改用 Android Studio。

3. **native 库未解包**
   已加 `android:extractNativeLibs="true"` 与 `useLegacyPackaging true`，
   让系统在安装时把 .so 解出来。若仍失败，检查这两个配置是否被覆盖。

4. **NDK 版本**
   `build.gradle` 里未硬钉 `ndkVersion`，用本机已装的 NDK。
   若某版本 NDK 缺 `sources/android/native_app_glue`，
   CMake 会给出明确报错（见 `CMakeLists.txt` 中的查找逻辑）。

### 应用闪退但日志只有一行堆栈

`GzrActivity` 的静态块已捕获 `UnsatisfiedLinkError`，
改为弹提示而非直接崩，并在 logcat（`tag: GuZhenRen`）里写明可能原因。

## 已知限制

| 项 | 说明 |
|---|---|
| **未真机验证** | 沙盒无 SDK/NDK、无模拟器，APK 未经编译与运行 |
| 字体体积 | 2 MB，占 APK 大头；可换子集化字体精简 |
| 缩放画质 | 最近邻采样，放大倍率大时会有锯齿 |
| 音效 | 无 |

## 平台无关层已验证

`AndroidViewport` 的 8 个用例在 Linux 上跑通（letterbox 计算、
坐标往返、黑边拒绝点击、捏合转滚轮、两种像素格式贴屏），
总测试 164 用例 / 3237 断言零失败。
真正依赖 NDK 的部分只能等有工具链的机器验证。
